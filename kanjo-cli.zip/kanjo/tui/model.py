"""Pure view-model transformations for the Kanjo TUI."""

from __future__ import annotations

import calendar
from dataclasses import dataclass, field
from datetime import datetime, date, timedelta, timezone
from enum import Enum
import math
import os
import re
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple
from zoneinfo import ZoneInfo

from .. import perf as _perf
from ..sources.base import AGENT_LABELS, local_zone, local_timezone_name
from ..providers import provider_for, PROVIDER_LABELS
from .i18n import t, normalize_lang
from .range_engine import (
    aggregate_models,
    build_range_helpers as _build_range_helpers,
    filtered_usage,
    window_start,
)

# Agent colours from ui/Sources/KanjoCore/AgentColors.swift, except that the TUI
# lightens the few entries that were too dark on a black terminal (commandcode,
# qwen, qodercli_cn, workbuddy_ai, omp; their 256-colour index sat near black and
# the 8-colour fallback was dark blue). The Mac app keeps the original colours.
AGENT_COLORS: Dict[str, Tuple[int, int, int]] = {
    "claude": (0xD9, 0x77, 0x57),
    "codex": (0x3E, 0x79, 0xD6),
    "antigravity": (0x7A, 0x6A, 0xD8),
    "grok": (0x0C, 0x7E, 0x86),
    "minimax": (0xD6, 0x3A, 0x8A),
    "qwen": (0x3B, 0x5B, 0xFF),
    "commandcode": (0x8C, 0x7A, 0xE6),
    "opencode": (0xB0, 0x8A, 0x1E),
    "copilot": (0x1F, 0x88, 0x3D),
    "pi": (0xC4, 0x1E, 0x3A),
    "workbuddy": (0xB6, 0x62, 0xCA),
    "workbuddy_ai": (0x3A, 0x96, 0x86),
    "grok_bot": (0xDC, 0x3C, 0x00),
    "qoderwork": (0x82, 0x3D, 0x44),
    "qodercli": (0x6E, 0x7F, 0x15),
    "qodercli_cn": (0x9C, 0x3F, 0x9A),
    "zcode": (0x3C, 0x5A, 0x31),
    "kimicode": (0x98, 0x5C, 0x26),
    "musecode": (0xC7, 0x7C, 0x80),
    "codebuddy": (0x00, 0xA0, 0x97),
    "qoder_ide": (0x24, 0x8B, 0xB2),
    "hermes": (0xA2, 0xA6, 0x00),
    "openclaw": (0xA8, 0x00, 0x5C),
    "devin": (0x00, 0x66, 0x94),
    "mimocode": (0xC2, 0x7C, 0x38),
    "prime_agent": (0x8F, 0x32, 0xD0),
    "omp": (0x34, 0x8F, 0x9E),
    "deepseek_harness": (0x00, 0x44, 0xA0),
    "qwenwork": (0x00, 0xA0, 0x6B),
}
DEFAULT_AGENT_COLOR = (0x9A, 0x9A, 0x9A)


def agent_color(agent: str) -> Tuple[int, int, int]:
    return AGENT_COLORS.get(agent, DEFAULT_AGENT_COLOR)


class TimeRange(str, Enum):
    ALL = "all"
    TODAY = "today"
    DAYS_7 = "7d"
    DAYS_30 = "30d"
    RESET = "reset"
    CYCLE = "cycle"


RANGE_TABS: List[Tuple[TimeRange, str]] = [
    (TimeRange.ALL, "All"),
    (TimeRange.TODAY, "Today"),
    (TimeRange.DAYS_7, "7d"),
    (TimeRange.DAYS_30, "30d"),
    (TimeRange.RESET, "Since reset"),
    (TimeRange.CYCLE, "Cycle"),
]


class ViewMode(str, Enum):
    PROJECTS = "projects"
    MODELS = "models"
    AGENTS = "agents"
    DAYS = "days"
    ACCOUNTS = "accounts"


# Second element is an i18n key (``view.*``); translate with ``t(key, lang)`` at display time.
VIEW_MODES: List[Tuple[ViewMode, str]] = [
    (ViewMode.PROJECTS, "view.projects"),
    (ViewMode.MODELS, "view.models"),
    (ViewMode.AGENTS, "view.agents"),
    (ViewMode.DAYS, "view.days"),
    (ViewMode.ACCOUNTS, "view.accounts"),
]


def available_view_modes(has_accounts: bool) -> List[Tuple[ViewMode, str]]:
    """Views present in the Tab / F3 cycle: Accounts only with account data."""
    if has_accounts:
        return list(VIEW_MODES)
    return [(v, name) for v, name in VIEW_MODES if v != ViewMode.ACCOUNTS]


class QuotaLevel(str, Enum):
    NORMAL = "normal"
    WARNING = "warning"
    CRITICAL = "critical"


def quota_level(percent: Optional[float]) -> Optional[QuotaLevel]:
    if percent is None or not math.isfinite(percent):
        return None
    if percent >= 95.0:
        return QuotaLevel.CRITICAL
    if percent >= 80.0:
        return QuotaLevel.WARNING
    return QuotaLevel.NORMAL


# ---- Formatting Helpers ----

def format_tokens(n: int, lang: str = "en") -> str:
    """Format token count in compact format: 1.21B, 266.2M, 45.2k, 500.

    In Chinese, uses 万 / 亿 / 万亿 units like the macOS app
    (``ui/Sources/KanjoCore/Formatting.swift``): < 10,000 is a plain number,
    otherwise one decimal with a trailing ``.0`` removed.
    """
    v = abs(float(n))
    sign = "-" if n < 0 else ""
    if normalize_lang(lang) == "zh":
        if v < 10_000:
            return sign + str(int(v))
        units = ((1e4, "万", False), (1e8, "亿", False), (1e12, "万亿", True))
        for base, suffix, last in units:
            scaled = v / base
            if scaled >= 1000:
                rounded_int = float(round(scaled))
                if rounded_int < 10000 or last:
                    return sign + str(int(rounded_int)) + suffix
                continue
            rounded = round(scaled * 10) / 10.0
            if rounded >= 1000:
                rounded_int = float(round(scaled))
                if rounded_int < 10000 or last:
                    return sign + str(int(rounded_int)) + suffix
                continue
            body = "%.1f" % rounded
            if body.endswith(".0"):
                body = body[:-2]
            return sign + body + suffix
        return sign + str(int(v))
    if v < 1000:
        return sign + str(int(v))
    if v < 1_000_000:
        scaled = v / 1000.0
        if scaled < 10:
            s = f"{scaled:.1f}k"
        else:
            s = f"{round(scaled)}k"
        if s.endswith(".0k"):
            s = s[:-3] + "k"
        return sign + s
    if v < 1_000_000_000:
        scaled = v / 1_000_000.0
        s = f"{scaled:.1f}M"
        if s.endswith(".0M"):
            s = s[:-3] + "M"
        return sign + s
    scaled = v / 1_000_000_000.0
    if scaled < 10:
        s = f"{scaled:.2f}B"
        if s.endswith("0B"):
            s = s[:-2] + "B"
        if s.endswith(".0B"):
            s = s[:-3] + "B"
    else:
        s = f"{scaled:.1f}B"
        if s.endswith(".0B"):
            s = s[:-3] + "B"
    return sign + s


def format_money(amount: float) -> str:
    """Format USD currency amount, e.g. $275.99, -$5.00, $0.00."""
    if not math.isfinite(amount):
        return "—"
    if amount < 0:
        return f"-${abs(amount):,.2f}"
    return f"${amount:,.2f}"


def format_speed(tps: Optional[float]) -> str:
    """Format output speed in tokens/sec, e.g. ``136.9/s``, or ``—``."""
    if tps is None or not math.isfinite(tps) or tps < 0:
        return "—"
    return f"{tps:.1f}/s"


def format_ttft(seconds: Optional[float]) -> str:
    """Format median TTFT: ``893ms`` when < 1s, ``1.09s`` when >= 1s, or ``—``."""
    if seconds is None or not math.isfinite(seconds) or seconds < 0:
        return "—"
    ms = int(round(seconds * 1000))
    if ms < 1000:
        return f"{ms}ms"
    return f"{seconds:.2f}s"


def format_percent(ratio: Optional[float]) -> str:
    """Format a 0..1 ratio as percentage: ``98%``, ``0.4%``, ``100%``, or ``—``."""
    if ratio is None or not math.isfinite(ratio):
        return "—"
    p = max(0.0, ratio * 100.0)
    if p >= 99.95:
        return "100%"
    if p == 0.0:
        return "0%"
    if p < 1.0:
        return f"{p:.1f}%"
    return f"{p:.0f}%"


def cache_hit_rate(input_tokens: int, cache_read: int) -> Optional[float]:
    """Compute cache hit rate ``cache_read / (input + cache_read)``; ``None`` when denom <= 0."""
    denom = input_tokens + cache_read
    if denom <= 0:
        return None
    return cache_read / denom


def ensure_aware(dt: Optional[datetime], tz: Optional[datetime.tzinfo] = None) -> Optional[datetime]:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=tz or timezone.utc)
    return dt


def parse_iso_dt(value: Optional[str], default_tz: Optional[datetime.tzinfo] = None) -> Optional[datetime]:
    if not value or not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return None
    if text.endswith(("Z", "z")):
        text = text[:-1] + "+00:00"
    match = re.match(r"^(.*?\.\d{1,6})\d*(.*)$", text)
    if match:
        text = match.group(1) + match.group(2)
    try:
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=default_tz or timezone.utc)
        return dt
    except (ValueError, TypeError):
        return None


_WINDOW_TITLE_WORDS = (
    (re.compile(r"weekly|week", re.IGNORECASE), "每周"),
    (re.compile(r"monthly|month", re.IGNORECASE), "每月"),
    (re.compile(r"daily|day", re.IGNORECASE), "每日"),
    (re.compile(r"5[- ]?hours?", re.IGNORECASE), "5小时"),
    (re.compile(r"5h", re.IGNORECASE), "5小时"),
)


def localize_window_title(title: str, lang: Optional[str]) -> str:
    """Localize the descriptive part of a data-supplied quota window title.

    Brand / model names are kept as-is (``Claude/GPT Weekly`` becomes
    ``Claude/GPT 每周``); unknown titles are returned unchanged.
    """
    if normalize_lang(lang) != "zh" or not title:
        return title
    out = title
    for pattern, replacement in _WINDOW_TITLE_WORDS:
        out = pattern.sub(replacement, out, count=1)
    return out


def _extra_window_title(ew_id: str, raw_title, lang: str) -> str:
    """Localized title for an Antigravity ``extra_windows`` entry.

    The Claude/GPT (3p) buckets share the ids ``3p-weekly`` / ``3p-5h`` and get
    a dedicated localized label; every other id keeps the (localized) title
    the CLI supplied.
    """
    if ew_id == "3p-weekly":
        return t("meter.claude_gpt_weekly", lang)
    if ew_id == "3p-5h":
        return t("meter.claude_gpt_five_hour", lang)
    return localize_window_title(str(raw_title or t("meter.extra", lang)), lang)


def format_reset_countdown(reset_dt: Optional[datetime], now: datetime, tz: datetime.tzinfo,
                           lang: str = "en") -> str:
    """Format relative countdown to reset_dt: resets in 2d 4h, resets 18:40, resets in 35m."""
    if reset_dt is None:
        return "—"
    now_utc = ensure_aware(now, tz) or datetime.now(timezone.utc)
    reset_utc = ensure_aware(reset_dt, tz)
    if reset_utc is None:
        return "—"
    now_utc = now_utc.astimezone(timezone.utc)
    reset_utc = reset_utc.astimezone(timezone.utc)
    diff = (reset_utc - now_utc).total_seconds()
    if diff <= 0:
        return t("meter.window_ended", lang)
    minutes = max(1, math.ceil(diff / 60))
    if minutes < 60:
        return t("meter.reset.in_m", lang, minutes=minutes)
    if minutes < 1440:
        # Check if same local day
        local_reset = reset_utc.astimezone(tz)
        local_now = now_utc.astimezone(tz)
        if local_reset.date() == local_now.date():
            return t("meter.reset.at", lang, time=local_reset.strftime('%H:%M'))
        h = minutes // 60
        m = minutes % 60
        return t("meter.reset.in_hm", lang, hours=h, minutes=m)
    d = minutes // 1440
    h = (minutes % 1440) // 60
    return t("meter.reset.in_dh", lang, days=d, hours=h)


def get_tz(doc: Optional[dict] = None) -> datetime.tzinfo:
    name = None
    if isinstance(doc, dict):
        name = doc.get("timezone")
    if not name:
        try:
            name = local_timezone_name()
        except Exception:
            name = "UTC"
    try:
        return ZoneInfo(name)
    except Exception:
        try:
            return local_zone(name)
        except Exception:
            return timezone.utc


def format_month_day_time(dt: datetime, tz: datetime.tzinfo, lang: str = "en",
                          now: Optional[datetime] = None) -> str:
    """Format e.g. ``Nov 8 16:55`` (en) or ``11月8日 16:55`` / ``今天 16:55`` (zh)."""
    local_dt = (ensure_aware(dt, tz) or datetime.now(tz)).astimezone(tz)
    if normalize_lang(lang) == "zh":
        now_dt = ensure_aware(now, tz) or datetime.now(tz)
        now_local = now_dt.astimezone(tz)
        if local_dt.date() == now_local.date():
            return t("time.today", lang, time=local_dt.strftime("%H:%M"))
        return f"{local_dt.month}月{local_dt.day}日 {local_dt.strftime('%H:%M')}"
    return f"{local_dt.strftime('%b')} {local_dt.day} {local_dt.strftime('%H:%M')}"


def get_accounts_window(quota_windows: Optional[dict], subscriptions: Optional[dict],
                        now: Optional[datetime] = None, tz_name: Optional[str] = None,
                        lang: str = "en") -> Tuple[datetime, str, str]:
    """Window = current Antigravity weekly quota window start (weekly_resets_at − window hours),
    else billing cycle start, else last 7 days.
    Returns (window_start_dt, kind, label).
    """
    tz = get_tz({"timezone": tz_name}) if tz_name else get_tz()
    now = ensure_aware(now, tz) or datetime.now(tz)
    qw = quota_windows or {}
    subs = subscriptions or {}

    # 1. Antigravity weekly quota window
    if isinstance(qw.get("antigravity"), dict) and qw["antigravity"].get("weekly_resets_at"):
        start = window_start(qw["antigravity"], now, tz)
        if start is not None:
            lbl = t("accounts.title.quota_week", lang, when=format_month_day_time(start, tz, lang, now))
            return start, "quota_week", lbl

    # 2. Antigravity billing cycle start
    if isinstance(subs.get("antigravity"), dict) and subs["antigravity"].get("cycle_start"):
        start = parse_iso_dt(subs["antigravity"]["cycle_start"], default_tz=tz)
        if start is not None:
            lbl = t("accounts.title.billing_cycle", lang, when=format_month_day_time(start, tz, lang, now))
            return start, "billing_cycle", lbl

    # 3. Fallback: last 7 days
    start = now - timedelta(days=7)
    lbl = t("accounts.title.last_7d", lang, when=format_month_day_time(start, tz, lang, now))
    return start, "last_7d", lbl


# ---- HeatStrip & Sparkline ----

_BLOCK_CHARS = " ▂▃▄▅▆▇█"
_ASCII_CHARS = " .:-=+*#%"


def heat_level(value: float, peak: float, levels: int = 8) -> int:
    if value <= 0 or peak <= 0:
        return 0
    ratio = min(value / peak, 1.0)
    return min(max(1, math.ceil(ratio * levels)), levels)


def compute_8w_strip(by_day: Optional[List[dict]], now: datetime, tz: datetime.tzinfo,
                     fallback_agent: str = "unknown", ascii_mode: bool = False) -> List[Tuple[str, Optional[str]]]:
    """Compute 8-week heat strip ending on the week of `now`.
    Returns list of 8 (char, dominant_agent) pairs, oldest week first.
    """
    now = ensure_aware(now, tz) or datetime.now(tz)
    now_local = now.astimezone(tz)
    today = datetime(now_local.year, now_local.month, now_local.day, tzinfo=tz)
    monday_offset = today.weekday()  # Monday = 0
    this_monday = today - timedelta(days=monday_offset)

    # 8 weeks of start dates (Mondays)
    week_starts = [this_monday - timedelta(days=7 * (7 - i)) for i in range(8)]
    week_costs: List[float] = [0.0] * 8
    week_agent_costs: List[Dict[str, float]] = [{} for _ in range(8)]

    first_start = week_starts[0]
    first_date = first_start.date()

    for d in (by_day or []):
        if not isinstance(d, dict):
            continue
        d_str = d.get("day")
        if not d_str:
            continue
        try:
            d_date = date.fromisoformat(str(d_str))
        except (ValueError, TypeError):
            continue
        days_from_first = (d_date - first_date).days
        if days_from_first < 0:
            continue
        w_idx = days_from_first // 7
        if w_idx >= 8:
            continue
        try:
            c = float(d.get("cost") or 0.0)
        except (ValueError, TypeError):
            c = 0.0
        week_costs[w_idx] += c
        split = d.get("by_agent")
        if isinstance(split, dict):
            for ag, cost_val in split.items():
                try:
                    cv = float(cost_val or 0.0)
                except (ValueError, TypeError):
                    cv = 0.0
                week_agent_costs[w_idx][ag] = week_agent_costs[w_idx].get(ag, 0.0) + cv
        else:
            week_agent_costs[w_idx][fallback_agent] = week_agent_costs[w_idx].get(fallback_agent, 0.0) + c

    peak = max(week_costs) if week_costs else 0.0
    out: List[Tuple[str, Optional[str]]] = []
    for i in range(8):
        c = week_costs[i]
        lvl = heat_level(c, peak, 8)
        # Dominant agent
        top_ag = None
        if week_agent_costs[i]:
            top_ag = max(week_agent_costs[i].items(), key=lambda kv: kv[1])[0]
        if lvl == 0:
            char = " " if ascii_mode else " "
            out.append((char, None))
        else:
            char = _ASCII_CHARS[lvl] if ascii_mode else _BLOCK_CHARS[lvl - 1]
            out.append((char, top_ag or fallback_agent))
    return out


def compute_30d_sparkline(by_day: Optional[List[dict]], now: datetime, tz: datetime.tzinfo,
                          ascii_mode: bool = False) -> Tuple[str, float]:
    """Compute 30-day sparkline ending on `today`. Returns (sparkline_string, peak_cost)."""
    now = ensure_aware(now, tz) or datetime.now(tz)
    now_local = now.astimezone(tz)
    today = datetime(now_local.year, now_local.month, now_local.day, tzinfo=tz)
    day_map: Dict[str, float] = {}
    for d in (by_day or []):
        if not isinstance(d, dict):
            continue
        d_str = d.get("day")
        if d_str:
            try:
                c = float(d.get("cost") or 0.0)
            except (ValueError, TypeError):
                c = 0.0
            day_map[str(d_str)] = day_map.get(str(d_str), 0.0) + c

    days = [(today - timedelta(days=29 - i)).date().isoformat() for i in range(30)]
    costs = [day_map.get(day_str, 0.0) for day_str in days]
    peak = max(costs) if costs else 0.0

    chars = []
    for c in costs:
        lvl = heat_level(c, peak, 8)
        if lvl == 0:
            chars.append("." if ascii_mode else " ")
        else:
            chars.append(_ASCII_CHARS[lvl] if ascii_mode else _BLOCK_CHARS[lvl - 1])
    return "".join(chars), peak
    return "".join(chars), peak


# ---- Range Filtering ----

@dataclass
class FilteredData:
    time_range: TimeRange
    projects: List[dict]
    unattributed: dict
    excluded: dict
    parse_failed_count: int
    total_cost: float
    total_tokens: int
    total_sessions: int
    projects_count: int
    agent_shares: List[Tuple[str, str, float, float]]  # (agent, label, cost, share_pct)
    by_day: List[dict]  # aggregated daily costs across all filtered projects
    by_model: List[dict]  # aggregated models across all filtered projects
    by_agent: List[dict]  # aggregated agents view rows
    first_active: Optional[str] = None
    last_active: Optional[str] = None


@dataclass
class PerfSummary:
    output_tokens: int
    gen_seconds: float
    sample_count: int
    ttft_histogram: Dict[str, int]
    tps: Optional[float]
    ttft_median: Optional[float]


def _summarize_perf(doc: dict, time_range: TimeRange, now: Optional[datetime],
                    key_field: str, agent_filter: Optional[str] = None) -> Dict[str, PerfSummary]:
    """Aggregate ``perf_by_day`` over ``time_range`` keyed by ``key_field`` using ``kanjo.perf``."""
    doc = doc or {}
    rows = doc.get("perf_by_day")
    if not rows or not isinstance(rows, list):
        return {}
    _tz, _now, _ag_win, day_included, _sess_inc, _sess_ct = _build_range_helpers(doc, time_range, now=now)
    acc: Dict[str, dict] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        ag = str(row.get("agent") or "")
        if not ag:
            continue
        if agent_filter is not None and ag != agent_filter:
            continue
        key = str(row.get(key_field) or "")
        if not key:
            continue
        if time_range != TimeRange.ALL and not day_included(str(row.get("day") or ""), ag):
            continue
        try:
            n = int(row.get("n", 0) or 0)
            o = int(row.get("o", 0) or 0)
            g = float(row.get("g", 0.0) or 0.0)
        except (TypeError, ValueError):
            continue
        if n <= 0 and o <= 0 and g <= 0.0:
            continue
        _perf.merge_perf(acc, {key: row})

    out: Dict[str, PerfSummary] = {}
    for key, stats in acc.items():
        if stats["n"] <= 0 or stats["g"] <= 0:
            continue
        tps = _perf.avg_tps(stats["o"], stats["g"])
        ttft = _perf.ttft_median(stats["th"])
        out[key] = PerfSummary(
            output_tokens=stats["o"],
            gen_seconds=stats["g"],
            sample_count=stats["n"],
            ttft_histogram=stats["th"],
            tps=tps,
            ttft_median=ttft,
        )
    return out


def compute_agent_perf(doc: dict, time_range: TimeRange = TimeRange.ALL,
                       now: Optional[datetime] = None) -> Dict[str, PerfSummary]:
    """Compute output speed and median TTFT per agent for ``time_range``."""
    return _summarize_perf(doc, time_range, now, key_field="agent")


def compute_agent_model_perf(doc: dict, agent: str, time_range: TimeRange = TimeRange.ALL,
                             now: Optional[datetime] = None) -> Dict[str, PerfSummary]:
    """Compute output speed and median TTFT per model for one agent over ``time_range``."""
    return _summarize_perf(doc, time_range, now, key_field="model", agent_filter=agent)


def _filtered_project_dict(fp) -> dict:
    p = dict(fp.project)
    p["cost"] = fp.cost
    p["tokens"] = {"total": fp.tokens}
    p["sessions"] = fp.sessions
    p["by_agent"] = fp.by_agent
    p["by_day"] = fp.by_day
    p["sessions_detail"] = fp.sessions_detail
    p["first_active"] = fp.first_active
    p["last_active"] = fp.last_active
    return p


def _filtered_bucket_dict(b) -> dict:
    return {
        "cost": b.cost,
        "tokens": {"total": b.tokens},
        "sessions": b.sessions,
        "sessions_detail": b.sessions_detail,
        "first_active": b.first_active,
        "last_active": b.last_active,
    }


def filter_report(doc: dict, time_range: TimeRange = TimeRange.ALL,
                  now: Optional[datetime] = None) -> FilteredData:
    """Filter projects and totals by selected range, matching TimeRange.swift semantics."""
    doc = doc or {}
    fu = filtered_usage(doc, time_range, now=now)
    tz, now_dt, _, _, _, session_in_range_cost_tokens = _build_range_helpers(doc, time_range, now=now)

    filtered_projects = [_filtered_project_dict(fp) for fp in fu.projects]
    filtered_projects.sort(key=lambda p: (-p.get("cost", 0.0), str(p.get("name", "")).lower()))
    filtered_unattr = _filtered_bucket_dict(fu.unattributed)
    filtered_excl = _filtered_bucket_dict(fu.excluded)

    buckets = doc.get("buckets") or {}
    parse_failed = buckets.get("parse_failed") or {}
    try:
        failed_count = int(parse_failed.get("sessions") or 0) if isinstance(parse_failed, dict) else 0
    except (ValueError, TypeError):
        failed_count = 0

    total_cost = fu.cost
    total_tokens = fu.tokens
    total_sessions = fu.sessions

    active_projects = [
        p for p in filtered_projects
        if time_range == TimeRange.ALL or p["cost"] > 0 or p["tokens"]["total"] > 0 or p["sessions"] > 0
    ]

    agent_cost_total: Dict[str, float] = {}
    for p in filtered_projects:
        for a in (p.get("by_agent") or []):
            if not isinstance(a, dict):
                continue
            ag = a.get("agent", "")
            try:
                acost = float(a.get("cost", 0.0) or 0.0)
            except (ValueError, TypeError):
                acost = 0.0
            agent_cost_total[ag] = agent_cost_total.get(ag, 0.0) + acost
    for s in (filtered_unattr.get("sessions_detail") or []) + (filtered_excl.get("sessions_detail") or []):
        if not isinstance(s, dict):
            continue
        sc, _ = session_in_range_cost_tokens(s)
        ag = s.get("agent", "")
        agent_cost_total[ag] = agent_cost_total.get(ag, 0.0) + sc

    agent_shares: List[Tuple[str, str, float, float]] = []
    tot_for_share = total_cost if total_cost > 0 else 1.0
    for ag, c in sorted(agent_cost_total.items(), key=lambda kv: (-kv[1], kv[0])):
        if c > 0 or time_range == TimeRange.ALL:
            share_pct = (c / tot_for_share) * 100.0
            agent_shares.append((ag, AGENT_LABELS.get(ag, ag), c, share_pct))

    daily_agg: Dict[str, Dict[str, Any]] = {}
    for p in filtered_projects:
        for d in (p.get("by_day") or []):
            if not isinstance(d, dict):
                continue
            d_str = d.get("day")
            if not d_str:
                continue
            if d_str not in daily_agg:
                daily_agg[d_str] = {"day": d_str, "cost": 0.0, "tokens": 0}
            try:
                d_c = float(d.get("cost", 0.0) or 0.0)
            except (ValueError, TypeError):
                d_c = 0.0
            try:
                d_t = int(d.get("tokens", 0) or 0)
            except (ValueError, TypeError):
                d_t = 0
            daily_agg[d_str]["cost"] += d_c
            daily_agg[d_str]["tokens"] += d_t

    by_day_list = sorted(daily_agg.values(), key=lambda d: d["day"], reverse=True)

    by_model_list = []
    for m in aggregate_models(fu):
        by_model_list.append({
            "model": m["model"],
            "agent": m["agent"],
            "provider": PROVIDER_LABELS.get(provider_for(m["model"], m["agent"]), "Other"),
            "cost": m["cost"],
            "tokens": m["tokens"],
            "estimated": m.get("estimated", False),
        })
    by_model_list.sort(key=lambda m: (-m["cost"], -m["tokens"], m["model"]))

    # Aggregated Agents View
    agent_rows: Dict[str, Dict[str, Any]] = {}
    for p in filtered_projects:
        for a in (p.get("by_agent") or []):
            if not isinstance(a, dict):
                continue
            ag = a.get("agent", "")
            if ag not in agent_rows:
                agent_rows[ag] = {
                    "agent": ag,
                    "label": a.get("label", AGENT_LABELS.get(ag, ag)),
                    "sessions": 0,
                    "tokens": 0,
                    "cost": 0.0,
                }
            try:
                acost = float(a.get("cost", 0.0) or 0.0)
            except (ValueError, TypeError):
                acost = 0.0
            try:
                asess = int(a.get("sessions", 0) or 0)
            except (ValueError, TypeError):
                asess = 0
            agent_rows[ag]["cost"] += acost
            agent_rows[ag]["sessions"] += asess
            tok_val = a.get("tokens") or {}
            try:
                tok_count = int(tok_val.get("total", 0) or 0) if isinstance(tok_val, dict) else int(tok_val or 0)
            except (ValueError, TypeError):
                tok_count = 0
            agent_rows[ag]["tokens"] += tok_count

    for s in (filtered_unattr.get("sessions_detail") or []) + (filtered_excl.get("sessions_detail") or []):
        if not isinstance(s, dict):
            continue
        sc, st = session_in_range_cost_tokens(s)
        ag = s.get("agent", "")
        if ag not in agent_rows:
            agent_rows[ag] = {
                "agent": ag,
                "label": AGENT_LABELS.get(ag, ag),
                "sessions": 0,
                "tokens": 0,
                "cost": 0.0,
            }
        agent_rows[ag]["cost"] += sc
        agent_rows[ag]["tokens"] += st
        agent_rows[ag]["sessions"] += 1

    agent_perf = compute_agent_perf(doc, time_range, now=now)
    by_agent_list = []
    for ag, row in sorted(agent_rows.items(), key=lambda kv: (-kv[1]["cost"], kv[0])):
        row_share = (row["cost"] / tot_for_share) * 100.0 if tot_for_share > 0 else 0.0
        row["share_pct"] = row_share
        perf = agent_perf.get(ag)
        row["tps"] = perf.tps if perf else None
        row["ttft_median"] = perf.ttft_median if perf else None
        row["perf_samples"] = perf.sample_count if perf else 0
        by_agent_list.append(row)

    first_act = min((p["first_active"] for p in filtered_projects if p.get("first_active")), default=None)
    last_act = max((p["last_active"] for p in filtered_projects if p.get("last_active")), default=None)

    return FilteredData(
        time_range=time_range,
        projects=active_projects,
        unattributed=filtered_unattr,
        excluded=filtered_excl,
        parse_failed_count=failed_count,
        total_cost=total_cost,
        total_tokens=total_tokens,
        total_sessions=total_sessions,
        projects_count=len(active_projects),
        agent_shares=agent_shares,
        by_day=by_day_list,
        by_model=by_model_list,
        by_agent=by_agent_list,
        first_active=first_act,
        last_active=last_act,
    )


# ---- View Models for Rendering ----

@dataclass
class TotalViewModel:
    cost_str: str
    tokens_str: str
    sessions_str: str
    projects_str: str
    shares: List[Tuple[str, str, float, float, Tuple[int, int, int]]]  # agent, label, cost, pct, rgb


@dataclass
class QuotaMeterWindow:
    name: str
    percent: Optional[float]
    level: Optional[QuotaLevel]
    detail: str
    placeholder: bool = False


@dataclass
class SubscriptionMeter:
    agent: str
    plan_label: str
    price_str: str
    usage_str: str
    multiplier_str: str
    color: Tuple[int, int, int]
    windows: List[QuotaMeterWindow]


@dataclass
class AntigravityAccountRow:
    email: str
    tokens_str: str
    cost_str: str
    is_current: bool
    is_unattributed: bool
    tokens_value: float = 0.0
    messages_str: str = "—"
    last_seen_str: str = "—"
    saved_login: bool = False


@dataclass
class AntigravityAccountsSection:
    header_label: str
    rows: List[AntigravityAccountRow]


@dataclass
class ProjectRowViewModel:
    id: str
    name: str
    cost_str: str
    tokens_str: str
    sessions_str: str
    agents: List[str]
    last_active_str: str
    heat_strip: List[Tuple[str, Optional[str]]]
    is_bucket: bool = False
    is_total: bool = False
    project: Optional[dict] = None


@dataclass
class ModelRowViewModel:
    model: str
    provider: str
    tokens_str: str
    cost_str: str


@dataclass
class AgentRowViewModel:
    agent: str
    label: str
    sessions_str: str
    tokens_str: str
    cost_str: str
    share_pct: float
    color: Tuple[int, int, int]
    speed_str: str = "—"
    ttft_str: str = "—"


@dataclass
class AgentModelRowViewModel:
    model: str
    tokens: int
    tokens_str: str
    hit_str: str
    speed_str: str
    cost: float
    cost_str: str
    estimated: bool = False


@dataclass
class AgentModelOthersViewModel:
    count: int
    tokens: int
    tokens_str: str
    cost: float
    cost_str: str


@dataclass
class AgentProjectShareViewModel:
    project_id: str
    project_name: str
    cost: float
    cost_str: str
    share: float
    share_str: str
    color: Tuple[int, int, int]


@dataclass
class AgentProjectOthersViewModel:
    count: int
    cost: float
    cost_str: str
    share: float
    share_str: str
    color: Tuple[int, int, int]


@dataclass
class AgentAccountShareViewModel:
    email: Optional[str]
    display_name: str
    tokens: int
    tokens_str: str
    cost: float
    cost_str: str
    messages: int
    share: float
    share_pct: int
    share_str: str
    is_unattributed: bool = False
    is_dimmed: bool = False


@dataclass
class AgentDetailViewModel:
    agent: str
    label: str
    color: Tuple[int, int, int]
    plan_label: Optional[str]
    price_str: Optional[str]
    multiplier_str: Optional[str]
    cost_str: str
    tokens_str: str
    sessions_str: str
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int
    cache_write_tokens: int
    input_str: str
    output_str: str
    cache_read_str: str
    cache_write_str: str
    cache_hit_rate: Optional[float]
    cache_hit_str: str
    tps: Optional[float]
    ttft_median: Optional[float]
    perf_samples: int
    speed_str: str
    ttft_str: str
    samples_str: str
    models: List[AgentModelRowViewModel]
    project_shares: List[AgentProjectShareViewModel]
    others_project_share: Optional[AgentProjectOthersViewModel]
    account_shares: List[AgentAccountShareViewModel] = field(default_factory=list)
    others_model: Optional[AgentModelOthersViewModel] = None


@dataclass
class DayRowViewModel:
    date_str: str
    cost_str: str
    tokens_str: str
    cost_ratio: float  # 0.0 to 1.0


@dataclass
class ProjectDetailViewModel:
    id: str
    name: str
    remote: Optional[str]
    paths: List[str]
    cost_str: str
    tokens_str: str
    sessions_str: str
    by_agent: List[Tuple[str, str, str, str, float, Tuple[int, int, int]]]  # label, cost, tok, sess, pct, rgb
    by_model: List[Tuple[str, str, str, str]]  # model, provider, cost, tok
    sparkline_30d: str
    sparkline_peak_str: str


def build_total_view_model(filtered: FilteredData, lang: str = "en") -> TotalViewModel:
    cost_str = format_money(filtered.total_cost)
    tok_str = t("total.tokens", lang, value=format_tokens(filtered.total_tokens, lang))
    sess_str = t("total.sessions", lang, count=filtered.total_sessions)
    proj_str = t("total.projects", lang, count=filtered.projects_count)
    shares = []
    for ag, lbl, c, pct in filtered.agent_shares:
        shares.append((ag, lbl, c, pct, agent_color(ag)))
    return TotalViewModel(
        cost_str=cost_str,
        tokens_str=tok_str,
        sessions_str=sess_str,
        projects_str=proj_str,
        shares=shares,
    )


def build_subscription_meters(doc: dict, now: Optional[datetime] = None,
                              lang: str = "en") -> List[SubscriptionMeter]:
    """Build htop CPU-meter style subscription blocks."""
    doc = doc or {}
    tz = get_tz(doc)
    now = ensure_aware(now, tz) or datetime.now(tz)
    subs = doc.get("subscriptions") or {}
    qw = doc.get("quota_windows") or {}
    if not subs or not isinstance(subs, dict):
        return []

    # Cycle usage for each agent
    cycle_filtered = filter_report(doc, TimeRange.CYCLE, now=now)
    usage_map = {row["agent"]: row["cost"] for row in cycle_filtered.by_agent}

    meters: List[SubscriptionMeter] = []
    for ag in sorted(subs.keys()):
        sub = subs[ag]
        if not isinstance(sub, dict):
            continue
        plan_label = sub.get("plan_label", ag)
        price = sub.get("monthly_price_usd")
        try:
            price = float(price) if price is not None else None
        except (ValueError, TypeError):
            price = None
        usage = float(usage_map.get(ag, 0.0) or 0.0)

        price_str = t("meter.per_month", lang, price=format_money(price)) if (price is not None and price > 0) else "—"
        usage_str = t("meter.usage", lang, amount=format_money(usage))
        if price is not None and price > 0 and usage > 0:
            multiplier = usage / price
            mult_str = f"{multiplier:.1f}×"
        else:
            mult_str = "—"

        # Quota windows
        q = qw.get(ag, {}) if isinstance(qw, dict) else {}
        if not isinstance(q, dict):
            q = {}
        windows: List[QuotaMeterWindow] = []

        # Weekly window
        weekly_reset = parse_iso_dt(q.get("weekly_resets_at"), default_tz=tz)
        weekly_hours = q.get("weekly_window_hours", 168)
        try:
            weekly_hours = float(weekly_hours if weekly_hours is not None else 168)
        except (ValueError, TypeError):
            weekly_hours = 168.0
        weekly_pct = q.get("weekly_used_percent")
        try:
            weekly_pct = float(weekly_pct) if weekly_pct is not None else None
        except (ValueError, TypeError):
            weekly_pct = None
        weekly_title = (t("meter.weekly", lang) if weekly_hours == 168
                        else t("meter.hours", lang, hours=int(round(weekly_hours))))

        if weekly_reset is not None:
            now_utc = now.astimezone(timezone.utc)
            reset_utc = weekly_reset.astimezone(timezone.utc)
            ended = reset_utc <= now_utc
            pct = None if ended else weekly_pct
            detail = t("meter.window_ended", lang) if ended else format_reset_countdown(weekly_reset, now, tz, lang)
            windows.append(QuotaMeterWindow(
                name=weekly_title,
                percent=pct,
                level=quota_level(pct),
                detail=detail,
            ))

        # 5-hour window
        five_hours = q.get("five_hour_window_hours")
        try:
            five_hours = float(five_hours) if five_hours is not None else None
        except (ValueError, TypeError):
            five_hours = None
        if five_hours is not None or q.get("five_hour_resets_at"):
            five_reset = parse_iso_dt(q.get("five_hour_resets_at"), default_tz=tz)
            five_pct = q.get("five_hour_used_percent")
            try:
                five_pct = float(five_pct) if five_pct is not None else None
            except (ValueError, TypeError):
                five_pct = None
            five_title = t("meter.five_hour", lang) if (not five_hours or five_hours == 5) else t("meter.hours", lang, hours=int(round(five_hours)))
            if five_reset is not None:
                now_utc = now.astimezone(timezone.utc)
                reset_utc = five_reset.astimezone(timezone.utc)
                ended = reset_utc <= now_utc
                pct = None if ended else five_pct
                detail = t("meter.window_ended", lang) if ended else format_reset_countdown(five_reset, now, tz, lang)
                windows.append(QuotaMeterWindow(
                    name=five_title,
                    percent=pct,
                    level=quota_level(pct),
                    detail=detail,
                ))

        # Extra windows (e.g. Claude & GPT weekly in Antigravity)
        for ew in (q.get("extra_windows") or []):
            if not isinstance(ew, dict):
                continue
            ew_reset = parse_iso_dt(ew.get("resets_at"), default_tz=tz)
            ew_pct = ew.get("used_percent")
            try:
                ew_pct = float(ew_pct) if ew_pct is not None else None
            except (ValueError, TypeError):
                ew_pct = None
            ew_id = str(ew.get("id") or "")
            ew_title = _extra_window_title(ew_id, ew.get("title"), lang)
            if ew_reset is not None:
                now_utc = now.astimezone(timezone.utc)
                reset_utc = ew_reset.astimezone(timezone.utc)
                ended = reset_utc <= now_utc
                pct = None if ended else ew_pct
                detail = t("meter.window_ended", lang) if ended else format_reset_countdown(ew_reset, now, tz, lang)
                windows.append(QuotaMeterWindow(
                    name=ew_title,
                    percent=pct,
                    level=quota_level(pct),
                    detail=detail,
                ))

        if not windows:
            # Present, but with no live quota data: show that the meter is
            # missing rather than silently drawing nothing.
            windows.append(QuotaMeterWindow(
                name=t("meter.quota", lang),
                percent=None,
                level=None,
                detail=t("meter.no_live_data", lang),
                placeholder=True,
            ))

        meters.append(SubscriptionMeter(
            agent=ag,
            plan_label=plan_label,
            price_str=price_str,
            usage_str=usage_str,
            multiplier_str=mult_str,
            color=agent_color(ag),
            windows=windows,
        ))

    return meters


def build_antigravity_accounts_section(
    doc: dict,
    now: Optional[datetime] = None,
    antigravity_data: Optional[Any] = None,
    current_account: Optional[str] = None,
    lang: str = "en",
) -> Optional[AntigravityAccountsSection]:
    """Build Antigravity accounts section if attribution data exists."""
    doc = doc or {}
    tz = get_tz(doc)
    now = ensure_aware(now, tz) or datetime.now(tz)
    qw = doc.get("quota_windows") or {}
    subs = doc.get("subscriptions") or {}
    window_start_dt, default_kind, default_header_label = get_accounts_window(
        qw, subs, now=now, tz_name=doc.get("timezone"), lang=lang
    )

    rows_data = antigravity_data if antigravity_data is not None else doc.get("antigravity_accounts")
    if not rows_data:
        return None

    # Case 1: Dict with schema {"window_start", "window_kind", "current", "accounts", "unknown"}
    if isinstance(rows_data, dict):
        w_start_iso = rows_data.get("window_start")
        w_start_dt = parse_iso_dt(w_start_iso, default_tz=tz) if w_start_iso else window_start_dt
        w_kind = rows_data.get("window_kind") or default_kind

        if w_kind == "quota_week":
            header_label = t("accounts.title.quota_week", lang,
                             when=format_month_day_time(w_start_dt, tz, lang, now) if w_start_dt else "—")
        elif w_kind == "billing_cycle":
            header_label = t("accounts.title.billing_cycle", lang,
                             when=format_month_day_time(w_start_dt, tz, lang, now) if w_start_dt else "—")
        else:
            header_label = t("accounts.title.last_7d", lang,
                             when=format_month_day_time(w_start_dt, tz, lang, now) if w_start_dt else "—")

        cur_acc = rows_data.get("current") or current_account
        accounts_list = rows_data.get("accounts") or []
        unknown_obj = rows_data.get("unknown") or {}

        out_rows: List[AntigravityAccountRow] = []
        for acc in accounts_list:
            if not isinstance(acc, dict):
                continue
            email = acc.get("email") or acc.get("account", "")
            if not email:
                continue
            toks = int(acc.get("tokens", 0) or 0)
            cost = float(acc.get("cost_usd") if "cost_usd" in acc else acc.get("cost", 0.0) or 0.0)
            try:
                msgs = int(acc.get("messages", 0) or 0)
            except (ValueError, TypeError):
                msgs = 0
            is_cur = False
            if cur_acc and str(email).lower() == str(cur_acc).lower():
                is_cur = True
            elif acc.get("is_current"):
                is_cur = True
            out_rows.append(AntigravityAccountRow(
                email=str(email),
                tokens_str=format_tokens(toks, lang),
                cost_str=format_money(cost),
                is_current=is_cur,
                is_unattributed=False,
                tokens_value=float(toks),
                messages_str=str(msgs),
                last_seen_str=_format_last_seen(acc.get("last_seen"), tz, lang, now),
                saved_login=bool(acc.get("saved_login")),
            ))

        out_rows.sort(key=lambda r: (-r.tokens_value, r.email.lower()))

        u_toks = int(unknown_obj.get("tokens", 0) or 0) if isinstance(unknown_obj, dict) else 0
        u_cost = float(unknown_obj.get("cost_usd", unknown_obj.get("cost", 0.0)) or 0.0) if isinstance(unknown_obj, dict) else 0.0
        if u_toks > 0 or u_cost > 0:
            out_rows.append(AntigravityAccountRow(
                email=t("accounts.unattributed", lang),
                tokens_str=format_tokens(u_toks, lang),
                cost_str=format_money(u_cost),
                is_current=False,
                is_unattributed=True,
                tokens_value=float(u_toks),
                messages_str="—",
                last_seen_str="—",
                saved_login=False,
            ))

        if not out_rows or not any(r.tokens_value > 0 or r.cost_str not in ("$0.00", "—") for r in out_rows):
            return None

        return AntigravityAccountsSection(header_label=header_label, rows=out_rows)

    # Case 2: List of dicts (legacy format)
    if isinstance(rows_data, list):
        has_any = any(
            isinstance(r, dict) and (r.get("account") not in ("unknown", "unattributed", "") or (r.get("tokens") or 0) > 0)
            for r in rows_data
        )
        if not has_any:
            return None

        out_rows = []
        unattr_row = None
        cur_acc = current_account

        for r in rows_data:
            if not isinstance(r, dict):
                continue
            acc = str(r.get("account") or r.get("email") or "").strip()
            toks = int(r.get("tokens", 0) or 0)
            cost = float(r.get("cost_usd") if "cost_usd" in r else r.get("cost", 0.0) or 0.0)
            is_cur = r.get("is_current", False)
            if cur_acc and acc.lower() == str(cur_acc).lower():
                is_cur = True
            try:
                msgs = int(r.get("messages", 0) or 0)
            except (ValueError, TypeError):
                msgs = 0

            if acc.lower() in ("unknown", "unattributed", ""):
                unattr_row = AntigravityAccountRow(
                    email=t("accounts.unattributed", lang),
                    tokens_str=format_tokens(toks, lang),
                    cost_str=format_money(cost),
                    is_current=False,
                    is_unattributed=True,
                    tokens_value=float(toks),
                    messages_str=str(msgs),
                    last_seen_str=_format_last_seen(r.get("last_seen"), tz, lang, now),
                    saved_login=bool(r.get("saved_login")),
                )
            else:
                out_rows.append(AntigravityAccountRow(
                    email=acc,
                    tokens_str=format_tokens(toks, lang),
                    cost_str=format_money(cost),
                    is_current=is_cur,
                    is_unattributed=False,
                    tokens_value=float(toks),
                    messages_str=str(msgs),
                    last_seen_str=_format_last_seen(r.get("last_seen"), tz, lang, now),
                    saved_login=bool(r.get("saved_login")),
                ))

        out_rows.sort(key=lambda r: (-r.tokens_value, r.email.lower()))
        if unattr_row is not None:
            out_rows.append(unattr_row)

        if not out_rows:
            return None
        return AntigravityAccountsSection(header_label=default_header_label, rows=out_rows)

    return None


def _format_last_seen(value: Optional[Any], tz: datetime.tzinfo, lang: str = "en",
                      now: Optional[datetime] = None) -> str:
    dt = parse_iso_dt(value if isinstance(value, str) else None, default_tz=tz)
    if dt is None:
        return "—"
    return format_month_day_time(dt, tz, lang, now)


def parse_tokens_str(tok_str: str) -> float:
    try:
        if tok_str.endswith("万亿"):
            return float(tok_str[:-2]) * 1e12
        if tok_str.endswith("亿"):
            return float(tok_str[:-1]) * 1e8
        if tok_str.endswith("万"):
            return float(tok_str[:-1]) * 1e4
        if tok_str.endswith("B"):
            return float(tok_str[:-1]) * 1e9
        if tok_str.endswith("M"):
            return float(tok_str[:-1]) * 1e6
        if tok_str.endswith("k"):
            return float(tok_str[:-1]) * 1e3
        return float(tok_str)
    except ValueError:
        return 0.0


def build_project_rows(filtered: FilteredData, now: datetime, tz: datetime.tzinfo,
                       ascii_mode: bool = False, filter_query: str = "",
                       lang: str = "en") -> List[ProjectRowViewModel]:
    """Build row view models for the Projects view table."""
    now = ensure_aware(now, tz) or datetime.now(tz)
    rows: List[ProjectRowViewModel] = []
    query = filter_query.strip().lower()

    for p in (filtered.projects if filtered else []):
        if not isinstance(p, dict):
            continue
        name = str(p.get("name") or "Unnamed")
        if query and query not in name.lower():
            continue
        c_str = format_money(float(p.get("cost") or 0.0))
        toks = p.get("tokens")
        total_toks = toks.get("total", 0) if isinstance(toks, dict) else int(toks or 0)
        t_str = format_tokens(total_toks, lang)
        s_str = str(int(p.get("sessions") or 0))
        agents = [
            a["agent"] for a in (p.get("by_agent") or [])
            if isinstance(a, dict) and (
                float(a.get("cost") or 0.0) > 0 or
                (isinstance(a.get("tokens"), dict) and a["tokens"].get("total", 0) > 0) or
                int(a.get("sessions") or 0) > 0
            )
        ]
        last_act = p.get("last_active") or "—"
        fallback_ag = agents[0] if agents else "unknown"
        heat = compute_8w_strip(p.get("by_day") or [], now, tz, fallback_agent=fallback_ag, ascii_mode=ascii_mode)

        rows.append(ProjectRowViewModel(
            id=str(p.get("id") or ""),
            name=name + (" (missing)" if p.get("path_missing") else ""),
            cost_str=c_str,
            tokens_str=t_str,
            sessions_str=s_str,
            agents=agents,
            last_active_str=str(last_act),
            heat_strip=heat,
            project=p,
        ))

    return rows


def build_project_footer_rows(filtered: FilteredData, now: datetime, tz: datetime.tzinfo,
                              ascii_mode: bool = False, lang: str = "en") -> List[ProjectRowViewModel]:
    """Footer rows for Projects view: Unattributed, Excluded, Parse failed, Total."""
    now = ensure_aware(now, tz) or datetime.now(tz)
    footers: List[ProjectRowViewModel] = []
    u = filtered.unattributed if filtered and isinstance(filtered.unattributed, dict) else {}
    e = filtered.excluded if filtered and isinstance(filtered.excluded, dict) else {}

    empty_heat = [(" " if ascii_mode else " ", None)] * 8

    # Unattributed
    u_c = format_money(float(u.get("cost") or 0.0))
    u_toks = u.get("tokens")
    u_t_val = u_toks.get("total", 0) if isinstance(u_toks, dict) else int(u_toks or 0)
    u_t = format_tokens(u_t_val, lang)
    u_s = str(int(u.get("sessions") or 0))
    u_last = u.get("last_active") or "—"
    footers.append(ProjectRowViewModel(
        id="__unattributed__",
        name=t("row.unattributed", lang),
        cost_str=u_c,
        tokens_str=u_t,
        sessions_str=u_s,
        agents=[],
        last_active_str=str(u_last),
        heat_strip=empty_heat,
        is_bucket=True,
    ))

    # Excluded
    e_c = format_money(float(e.get("cost") or 0.0))
    e_toks = e.get("tokens")
    e_t_val = e_toks.get("total", 0) if isinstance(e_toks, dict) else int(e_toks or 0)
    e_t = format_tokens(e_t_val, lang)
    e_s = str(int(e.get("sessions") or 0))
    e_last = e.get("last_active") or "—"
    footers.append(ProjectRowViewModel(
        id="__excluded__",
        name=t("row.excluded", lang),
        cost_str=e_c,
        tokens_str=e_t,
        sessions_str=e_s,
        agents=[],
        last_active_str=str(e_last),
        heat_strip=empty_heat,
        is_bucket=True,
    ))

    # Parse failed
    if filtered and filtered.parse_failed_count > 0:
        footers.append(ProjectRowViewModel(
            id="__parse_failed__",
            name=t("row.parse_failed", lang),
            cost_str="—",
            tokens_str="—",
            sessions_str=str(filtered.parse_failed_count),
            agents=[],
            last_active_str="—",
            heat_strip=empty_heat,
            is_bucket=True,
        ))

    # Total
    tot_c = format_money(filtered.total_cost if filtered else 0.0)
    tot_t = format_tokens(filtered.total_tokens if filtered else 0, lang)
    tot_s = str(filtered.total_sessions if filtered else 0)
    tot_last = (filtered.last_active if filtered else None) or "—"
    footers.append(ProjectRowViewModel(
        id="__total__",
        name=t("row.total", lang),
        cost_str=tot_c,
        tokens_str=tot_t,
        sessions_str=tot_s,
        agents=[],
        last_active_str=str(tot_last),
        heat_strip=empty_heat,
        is_total=True,
    ))

    return footers


def build_model_rows(filtered: FilteredData, filter_query: str = "",
                     lang: str = "en") -> List[ModelRowViewModel]:
    rows: List[ModelRowViewModel] = []
    query = filter_query.strip().lower()
    for m in (filtered.by_model if filtered else []):
        if not isinstance(m, dict):
            continue
        name = str(m.get("model") or "")
        prov = str(m.get("provider") or "Other")
        if query and query not in name.lower() and query not in prov.lower():
            continue
        rows.append(ModelRowViewModel(
            model=name,
            provider=prov,
            tokens_str=format_tokens(int(m.get("tokens") or 0), lang),
            cost_str=format_money(float(m.get("cost") or 0.0)),
        ))
    return rows


def build_agent_rows(filtered: FilteredData, filter_query: str = "",
                     lang: str = "en") -> List[AgentRowViewModel]:
    rows: List[AgentRowViewModel] = []
    query = filter_query.strip().lower()
    for a in (filtered.by_agent if filtered else []):
        if not isinstance(a, dict):
            continue
        lbl = str(a.get("label") or a.get("agent") or "")
        ag = str(a.get("agent") or "")
        if query and query not in lbl.lower() and query not in ag.lower():
            continue
        rows.append(AgentRowViewModel(
            agent=ag,
            label=lbl,
            sessions_str=str(int(a.get("sessions") or 0)),
            tokens_str=format_tokens(int(a.get("tokens") or 0), lang),
            cost_str=format_money(float(a.get("cost") or 0.0)),
            share_pct=float(a.get("share_pct") or 0.0),
            color=agent_color(ag),
            speed_str=format_speed(a.get("tps")),
            ttft_str=format_ttft(a.get("ttft_median")),
        ))
    return rows


def build_day_rows(filtered: FilteredData, filter_query: str = "",
                   lang: str = "en") -> List[DayRowViewModel]:
    rows: List[DayRowViewModel] = []
    query = filter_query.strip().lower()
    peak = max((float(d.get("cost") or 0.0) for d in (filtered.by_day if filtered else []) if isinstance(d, dict)), default=0.0)
    for d in (filtered.by_day if filtered else []):
        if not isinstance(d, dict):
            continue
        d_str = str(d.get("day") or "")
        if query and query not in d_str.lower():
            continue
        c = float(d.get("cost") or 0.0)
        ratio = (c / peak) if peak > 0 else 0.0
        rows.append(DayRowViewModel(
            date_str=d_str,
            cost_str=format_money(c),
            tokens_str=format_tokens(int(d.get("tokens") or 0), lang),
            cost_ratio=ratio,
        ))
    return rows


def build_project_detail(project: dict, now: datetime, tz: datetime.tzinfo,
                         ascii_mode: bool = False, lang: str = "en") -> ProjectDetailViewModel:
    """Build detail pane model for a selected project."""
    project = project or {}
    now = ensure_aware(now, tz) or datetime.now(tz)
    name = str(project.get("name") or "Unnamed")
    remote = project.get("remote")
    paths = project.get("paths") or []
    cost_str = format_money(float(project.get("cost") or 0.0))
    tok_val = project.get("tokens")
    tok_count = tok_val.get("total", 0) if isinstance(tok_val, dict) else int(tok_val or 0)
    tokens_str = format_tokens(tok_count, lang)
    sessions_str = str(int(project.get("sessions") or 0))

    # Breakdown by agent
    by_agent: List[Tuple[str, str, str, str, float, Tuple[int, int, int]]] = []
    tot_c = float(project.get("cost") or 0.0) or 1.0
    for a in (project.get("by_agent") or []):
        if not isinstance(a, dict):
            continue
        ag = str(a.get("agent") or "")
        c = float(a.get("cost") or 0.0)
        tok_n = a.get("tokens", {}).get("total", 0) if isinstance(a.get("tokens"), dict) else int(a.get("tokens") or 0)
        s = int(a.get("sessions") or 0)
        pct = (c / tot_c) * 100.0
        by_agent.append((
            str(a.get("label") or AGENT_LABELS.get(ag, ag)),
            format_money(c),
            format_tokens(tok_n, lang),
            str(s),
            pct,
            agent_color(ag),
        ))

    # Breakdown by model
    by_model: List[Tuple[str, str, str, str]] = []
    for m in (project.get("by_model") or []):
        if not isinstance(m, dict):
            continue
        m_name = str(m.get("model") or "")
        ag = str(m.get("agent") or "")
        prov = PROVIDER_LABELS.get(provider_for(m_name, ag), "Other")
        c = float(m.get("cost") or 0.0)
        tok_n = m.get("tokens", {}).get("total", 0) if isinstance(m.get("tokens"), dict) else int(m.get("tokens") or 0)
        by_model.append((
            m_name,
            prov,
            format_money(c),
            format_tokens(tok_n, lang),
        ))

    # 30-day sparkline
    spark, peak = compute_30d_sparkline(project.get("by_day") or [], now, tz, ascii_mode=ascii_mode)
    peak_str = t("detail.peak", lang, money=format_money(peak))

    return ProjectDetailViewModel(
        id=str(project.get("id") or ""),
        name=name,
        remote=remote,
        paths=paths,
        cost_str=cost_str,
        tokens_str=tokens_str,
        sessions_str=sessions_str,
        by_agent=by_agent,
        by_model=by_model,
        sparkline_30d=spark,
        sparkline_peak_str=peak_str,
    )


def _apportion(total: int, weights: List[float], equal_if_zero: bool = False) -> List[int]:
    """Hamilton-Hare largest-remainder apportionment of integer ``total``."""
    if not weights or total <= 0:
        return [0] * len(weights)
    sum_w = sum(weights)
    if sum_w <= 0:
        if not equal_if_zero:
            return [0] * len(weights)
        norm = [1.0 / len(weights)] * len(weights)
    else:
        norm = [w / sum_w for w in weights]
    quotas = [total * w for w in norm]
    ints = [int(math.floor(q)) for q in quotas]
    leftover = total - sum(ints)
    remainders = sorted(
        [(quotas[i] - ints[i], i) for i in range(len(weights))],
        key=lambda item: (-round(item[0], 9), item[1]),
    )
    for _, idx in remainders[:max(0, leftover)]:
        ints[idx] += 1
    return ints


def _token_parts(toks: Any) -> Tuple[int, int, int, int, int]:
    """Return ``(input, output, cache_read, cache_write, total)`` from a tokens dict or int."""
    if isinstance(toks, dict):
        inp = int(toks.get("input", 0) or 0)
        out = int(toks.get("output", 0) or 0)
        cr = int(toks.get("cache_read", 0) or 0)
        cw = int(toks.get("cache_write", 0) or 0)
        tot = int(toks.get("total", 0) or 0)
        return inp, out, cr, cw, tot
    tot = int(toks or 0) if toks else 0
    return 0, 0, 0, 0, tot


def _exact_agent_breakdowns(doc: dict) -> Dict[str, Tuple[int, int, int, int, int]]:
    """Sum exact all-time ``(input, output, cache_read, cache_write, total)`` per agent."""
    out: Dict[str, List[int]] = {}
    for p in (doc.get("projects") or []):
        if not isinstance(p, dict):
            continue
        for a in (p.get("by_agent") or []):
            if not isinstance(a, dict):
                continue
            ag = str(a.get("agent") or "")
            if not ag:
                continue
            parts = _token_parts(a.get("tokens"))
            cur = out.setdefault(ag, [0, 0, 0, 0, 0])
            for i in range(5):
                cur[i] += parts[i]
    buckets = doc.get("buckets") or {}
    for b_name in ("unattributed", "excluded"):
        b = buckets.get(b_name) or {}
        for s in (b.get("sessions_detail") or []):
            if not isinstance(s, dict):
                continue
            ag = str(s.get("agent") or "")
            if not ag:
                continue
            parts = _token_parts(s.get("tokens"))
            cur = out.setdefault(ag, [0, 0, 0, 0, 0])
            for i in range(5):
                cur[i] += parts[i]
    return {ag: (v[0], v[1], v[2], v[3], v[4]) for ag, v in out.items()}


def _project_segment_color(agent: str, index: int) -> Tuple[int, int, int]:
    """Match the Mac app's per-project colour sequence for 'Where the money went'."""
    if index == 0:
        return agent_color(agent)
    palette = [k for k in ("codex", "grok", "antigravity", "opencode", "copilot") if k != agent]
    return agent_color(palette[(index - 1) % len(palette)])


def _email_local_part(email: str) -> str:
    return email.split("@", 1)[0]


def _account_display_name(email: str, all_emails: Sequence[str]) -> str:
    lp = _email_local_part(email)
    low = email.lower()
    if any(other.lower() != low and _email_local_part(other) == lp for other in all_emails):
        return email
    return lp


def _apportion_percentages(weights: Sequence[float]) -> List[int]:
    """Round non-negative weights to integer percentages summing to 100 (or 0 if all <= 0)."""
    n = len(weights)
    if n == 0:
        return []
    clean = [max(0.0, float(w)) for w in weights]
    total = sum(clean)
    if total <= 0.0:
        return [0] * n
    raw = [100.0 * w / total for w in clean]
    pcts = [int(math.floor(r)) for r in raw]
    rem = 100 - sum(pcts)
    if rem > 0:
        order = sorted(
            (i for i in range(n) if clean[i] > 0.0),
            key=lambda i: (-(raw[i] - pcts[i]), -clean[i], i),
        )
        for i in order[:rem]:
            pcts[i] += 1
    elif rem < 0:
        order = sorted(
            (i for i in range(n) if pcts[i] > 0),
            key=lambda i: ((raw[i] - pcts[i]), clean[i], -i),
        )
        for i in order[:-rem]:
            pcts[i] -= 1
    return pcts


def compute_antigravity_account_shares(
    doc: dict,
    time_range: TimeRange = TimeRange.ALL,
    now: Optional[datetime] = None,
    lang: str = "en",
) -> List[AgentAccountShareViewModel]:
    """Compute per-account Antigravity usage shares over ``time_range`` (day granularity).

    Returns an empty list when ``antigravity_accounts.by_day`` is missing/empty or has
    no usage in ``time_range``. Active accounts are sorted by tokens descending, followed
    by an Unattributed row (if any null-email usage exists in range), then zero-usage
    accounts from ``antigravity_accounts.accounts`` dimmed at the bottom. Integer
    percentages sum to 100 via largest-remainder rounding.
    """
    doc = doc or {}
    agy = doc.get("antigravity_accounts")
    if not isinstance(agy, dict):
        return []
    by_day = agy.get("by_day")
    if not isinstance(by_day, list) or not by_day:
        return []

    _tz, _now_dt, _ag_win, day_included, _sess_inc, _sess_ct = _build_range_helpers(
        doc, time_range, now=now
    )

    by_email: Dict[str, Tuple[str, int, float, int]] = {}
    unattr_tokens = 0
    unattr_cost = 0.0
    unattr_msgs = 0

    for entry in by_day:
        if not isinstance(entry, dict):
            continue
        if not day_included(entry.get("day"), "antigravity"):
            continue
        try:
            tok = int(entry.get("tokens") or 0)
        except (TypeError, ValueError):
            tok = 0
        raw_cost = entry.get("cost_usd") if entry.get("cost_usd") is not None else entry.get("cost")
        try:
            cost = float(raw_cost or 0.0)
        except (TypeError, ValueError):
            cost = 0.0
        try:
            msgs = int(entry.get("messages") or 0)
        except (TypeError, ValueError):
            msgs = 0

        raw_email = entry.get("email")
        email_clean = raw_email.strip() if isinstance(raw_email, str) else ""
        if email_clean:
            key = email_clean.lower()
            prev = by_email.get(key)
            if prev is None:
                by_email[key] = (email_clean, tok, cost, msgs)
            else:
                by_email[key] = (prev[0], prev[1] + tok, prev[2] + cost, prev[3] + msgs)
        else:
            unattr_tokens += tok
            unattr_cost += cost
            unattr_msgs += msgs

    total_tokens = sum(v[1] for v in by_email.values()) + unattr_tokens
    total_cost = sum(v[2] for v in by_email.values()) + unattr_cost
    if total_tokens <= 0 and total_cost <= 0:
        return []

    canonical_emails: List[str] = []
    seen_keys: Set[str] = set()
    for acc in (agy.get("accounts") or []):
        if not isinstance(acc, dict):
            continue
        raw_acc_email = acc.get("email") or acc.get("account")
        if not isinstance(raw_acc_email, str) or not raw_acc_email.strip():
            continue
        acc_email = raw_acc_email.strip()
        key = acc_email.lower()
        if key not in seen_keys:
            seen_keys.add(key)
            canonical_emails.append(acc_email)

    for key in sorted(by_email.keys()):
        if key not in seen_keys:
            seen_keys.add(key)
            canonical_emails.append(by_email[key][0])

    # Intermediate tuples: (email, display_name, tokens, cost, messages, is_unattr, is_dimmed)
    active_items: List[Tuple[Optional[str], str, int, float, int, bool, bool]] = []
    zero_items: List[Tuple[Optional[str], str, int, float, int, bool, bool]] = []

    for email in canonical_emails:
        key = email.lower()
        agg = by_email.get(key)
        tok = agg[1] if agg is not None else 0
        cost = agg[2] if agg is not None else 0.0
        msgs = agg[3] if agg is not None else 0
        disp = _account_display_name(email, canonical_emails)
        if tok > 0 or cost > 0:
            active_items.append((email, disp, tok, cost, msgs, False, False))
        else:
            zero_items.append((email, disp, 0, 0.0, 0, False, True))

    active_items.sort(key=lambda item: (-item[2], -item[3], (item[0] or "").lower()))

    ordered = list(active_items)
    if unattr_tokens > 0 or unattr_cost > 0:
        ordered.append((
            None,
            t("agent_detail.unattributed", lang),
            unattr_tokens,
            unattr_cost,
            unattr_msgs,
            True,
            False,
        ))
    ordered.extend(zero_items)

    weights = [float(item[2]) if total_tokens > 0 else float(item[3]) for item in ordered]
    denom = float(total_tokens) if total_tokens > 0 else float(total_cost)
    pcts = _apportion_percentages(weights)

    rows: List[AgentAccountShareViewModel] = []
    for (email, disp, tok, cost, msgs, is_unattr, is_dimmed), w, pct in zip(ordered, weights, pcts):
        frac = (w / denom) if denom > 0 else 0.0
        rows.append(AgentAccountShareViewModel(
            email=email,
            display_name=disp,
            tokens=tok,
            tokens_str=format_tokens(tok, lang),
            cost=cost,
            cost_str=format_money(cost),
            messages=msgs,
            share=frac,
            share_pct=pct,
            share_str=f"{pct}%",
            is_unattributed=is_unattr,
            is_dimmed=is_dimmed,
        ))
    return rows


def build_agent_detail(
    doc: dict,
    agent: str,
    time_range: TimeRange = TimeRange.ALL,
    now: Optional[datetime] = None,
    filtered: Optional[FilteredData] = None,
    lang: str = "en",
) -> AgentDetailViewModel:
    """Build detail pane view model for ``agent`` in ``time_range``."""
    doc = doc or {}
    tz, now_dt, _ag_win, _day_inc, _sess_inc, session_in_range_cost_tokens = (
        _build_range_helpers(doc, time_range, now=now)
    )
    if filtered is None or filtered.time_range != time_range:
        filtered = filter_report(doc, time_range, now=now_dt)

    agent_row = next((r for r in filtered.by_agent if r.get("agent") == agent), None)
    label = str((agent_row or {}).get("label") or AGENT_LABELS.get(agent, agent))
    for p in (doc.get("projects") or []):
        if label != agent:
            break
        if isinstance(p, dict):
            for a in (p.get("by_agent") or []):
                if isinstance(a, dict) and a.get("agent") == agent and a.get("label"):
                    label = str(a["label"])
                    break

    range_cost = float((agent_row or {}).get("cost") or 0.0)
    range_tokens = int((agent_row or {}).get("tokens") or 0)
    range_sessions = int((agent_row or {}).get("sessions") or 0)

    # Subscription metadata & billing-cycle multiplier
    subs = doc.get("subscriptions") or {}
    sub = subs.get(agent) if isinstance(subs, dict) else None
    plan_label: Optional[str] = None
    price_str: Optional[str] = None
    multiplier_str: Optional[str] = None
    if isinstance(sub, dict):
        plan_label = str(sub.get("plan_label") or agent)
        raw_price = sub.get("monthly_price_usd")
        try:
            price = float(raw_price) if raw_price is not None else None
        except (TypeError, ValueError):
            price = None
        if price is not None and price > 0:
            price_str = t("meter.per_month", lang, price=format_money(price))
            cycle_filtered = (
                filtered if time_range == TimeRange.CYCLE
                else filter_report(doc, TimeRange.CYCLE, now=now_dt)
            )
            cycle_usage = next(
                (float(r.get("cost") or 0.0) for r in cycle_filtered.by_agent if r.get("agent") == agent),
                0.0,
            )
            multiplier_str = f"{cycle_usage / price:.1f}×" if cycle_usage > 0 else "—"

    # Token breakdown (input / output / cache_read / cache_write)
    exact_map = _exact_agent_breakdowns(doc)
    exact = exact_map.get(agent)
    if time_range == TimeRange.ALL:
        if exact is not None and (exact[0] + exact[1] + exact[2] + exact[3] > 0 or exact[4] > 0):
            inp, out_tok, cr, cw, _tot = exact
        else:
            inp, out_tok, cr, cw = 0, 0, 0, 0
    else:
        if range_tokens <= 0:
            inp, out_tok, cr, cw = 0, 0, 0, 0
        else:
            w_in = w_out = w_cr = w_cw = 0.0
            in_range_sessions: List[dict] = []
            for p in filtered.projects:
                for s in (p.get("sessions_detail") or []):
                    if isinstance(s, dict) and s.get("agent") == agent:
                        in_range_sessions.append(s)
            for s in ((filtered.unattributed.get("sessions_detail") or [])
                      + (filtered.excluded.get("sessions_detail") or [])):
                if isinstance(s, dict) and s.get("agent") == agent:
                    in_range_sessions.append(s)
            for s in in_range_sessions:
                _, st = session_in_range_cost_tokens(s)
                if st <= 0:
                    continue
                s_in, s_out, s_cr, s_cw, s_tot = _token_parts(s.get("tokens"))
                denom = max(s_in + s_out + s_cr + s_cw, s_tot)
                if denom <= 0:
                    continue
                scale = st / denom
                w_in += s_in * scale
                w_out += s_out * scale
                w_cr += s_cr * scale
                w_cw += s_cw * scale
            if w_in + w_out + w_cr + w_cw > 0:
                weights = [w_in, w_out, w_cr, w_cw]
            elif exact is not None and (exact[0] + exact[1] + exact[2] + exact[3]) > 0:
                weights = [float(exact[0]), float(exact[1]), float(exact[2]), float(exact[3])]
            else:
                weights = []
            if weights:
                inp, out_tok, cr, cw = _apportion(range_tokens, weights)
            else:
                inp, out_tok, cr, cw = 0, 0, 0, 0

    hit_ratio = cache_hit_rate(inp, cr)

    # Performance summary for agent & per-model
    perf_map = compute_agent_perf(doc, time_range, now=now_dt)
    perf = perf_map.get(agent)
    tps = perf.tps if perf else None
    ttft_med = perf.ttft_median if perf else None
    samples = perf.sample_count if perf else 0
    if samples <= 0:
        samples_str = t("agent_detail.no_samples", lang)
    elif samples == 1:
        samples_str = t("agent_detail.samples.one", lang, count=f"{samples:,}")
    else:
        samples_str = t("agent_detail.samples.many", lang, count=f"{samples:,}")
    speed_detail_str = (
        t("agent_detail.tok_per_sec", lang, value=f"{tps:.1f}")
        if (tps is not None and math.isfinite(tps))
        else "—"
    )

    # Per-model table
    model_perf_map = compute_agent_model_perf(doc, agent, time_range, now=now_dt)
    all_time_est: Dict[str, bool] = {}
    for p in (doc.get("projects") or []):
        if not isinstance(p, dict):
            continue
        for m in (p.get("by_model") or []):
            if isinstance(m, dict) and m.get("agent") == agent:
                mn = str(m.get("model") or "")
                if mn:
                    all_time_est[mn] = all_time_est.get(mn, False) or bool(m.get("estimated"))

    # {model_name: [cost, inp, out, cr, cw, tot, estimated]}
    model_agg: Dict[str, List[Any]] = {}

    def add_model_entry(m_name: str, cost: float, m_inp: int, m_out: int, m_cr: int, m_cw: int, m_tot: int, est: bool) -> None:
        if not m_name:
            return
        cur = model_agg.get(m_name)
        if cur is None:
            model_agg[m_name] = [cost, m_inp, m_out, m_cr, m_cw, m_tot, est]
        else:
            cur[0] += cost
            cur[1] += m_inp
            cur[2] += m_out
            cur[3] += m_cr
            cur[4] += m_cw
            cur[5] += m_tot
            cur[6] = cur[6] or est

    if time_range == TimeRange.ALL:
        for p in (doc.get("projects") or []):
            if not isinstance(p, dict):
                continue
            for m in (p.get("by_model") or []):
                if not isinstance(m, dict) or m.get("agent") != agent:
                    continue
                m_name = str(m.get("model") or "")
                try:
                    mc = float(m.get("cost") or 0.0)
                except (TypeError, ValueError):
                    mc = 0.0
                mi, mo, mcr, mcw, mtot = _token_parts(m.get("tokens"))
                add_model_entry(m_name, mc, mi, mo, mcr, mcw, mtot, bool(m.get("estimated")))
    else:
        def process_sessions(sessions: List[dict], target_cost: float, target_tokens: int, apportion_targets: bool) -> None:
            ag_sessions = [s for s in sessions if isinstance(s, dict) and s.get("agent") == agent]
            if not ag_sessions:
                return
            if apportion_targets:
                if target_cost <= 0 and target_tokens <= 0:
                    return
                raw_pairs = [session_in_range_cost_tokens(s) for s in ag_sessions]
                raw_costs = [c for c, _ in raw_pairs]
                raw_toks = [float(tk) for _, tk in raw_pairs]
                sum_c = sum(raw_costs)
                if sum_c > 0:
                    sess_costs = [target_cost * (c / sum_c) for c in raw_costs]
                else:
                    eq = target_cost / len(ag_sessions)
                    sess_costs = [eq] * len(ag_sessions)
                sess_toks = _apportion(target_tokens, raw_toks, equal_if_zero=True)
            else:
                pairs = [session_in_range_cost_tokens(s) for s in ag_sessions]
                sess_costs = [c for c, _ in pairs]
                sess_toks = [tk for _, tk in pairs]

            for s, sc, st in zip(ag_sessions, sess_costs, sess_toks):
                models = [str(m) for m in (s.get("models") or []) if m]
                if not models or (sc <= 0 and st <= 0):
                    continue
                si, so, scr, scw, _ = _token_parts(s.get("tokens"))
                if si + so + scr + scw > 0:
                    si, so, scr, scw = _apportion(st, [float(si), float(so), float(scr), float(scw)])
                else:
                    si = so = scr = scw = 0
                cnt = len(models)
                if cnt == 1:
                    mn = models[0]
                    add_model_entry(mn, sc, si, so, scr, scw, st, all_time_est.get(mn, False))
                else:
                    share_c = sc / cnt
                    for idx_m, mn in enumerate(models):
                        def split_val(v: int) -> int:
                            base, rem = divmod(v, cnt)
                            return base + rem if idx_m == 0 else base

                        mi = split_val(si)
                        mo = split_val(so)
                        mcr = split_val(scr)
                        mcw = split_val(scw)
                        mtot = (mi + mo + mcr + mcw) if (si + so + scr + scw > 0) else split_val(st)
                        add_model_entry(mn, share_c, mi, mo, mcr, mcw, mtot, True)

        for p in filtered.projects:
            p_ag = next((a for a in (p.get("by_agent") or []) if isinstance(a, dict) and a.get("agent") == agent), None)
            if p_ag:
                p_cost = float(p_ag.get("cost") or 0.0)
                p_toks = _token_parts(p_ag.get("tokens"))[4]
                process_sessions(p.get("sessions_detail") or [], p_cost, p_toks, apportion_targets=True)
        process_sessions(filtered.unattributed.get("sessions_detail") or [], 0.0, 0, apportion_targets=False)
        process_sessions(filtered.excluded.get("sessions_detail") or [], 0.0, 0, apportion_targets=False)

    model_rows: List[AgentModelRowViewModel] = []
    for m_name, vals in model_agg.items():
        mc, mi, _mo, mcr, _mcw, mtot, est = vals
        if mtot <= 0 and mc <= 0:
            continue
        m_hit = cache_hit_rate(mi, mcr)
        m_perf = model_perf_map.get(m_name)
        m_tps = m_perf.tps if m_perf else None
        model_rows.append(AgentModelRowViewModel(
            model=m_name,
            tokens=mtot,
            tokens_str=format_tokens(mtot, lang),
            hit_str=format_percent(m_hit),
            speed_str=format_speed(m_tps),
            cost=mc,
            cost_str=format_money(mc),
            estimated=est,
        ))
    model_rows.sort(key=lambda r: (-r.cost, -r.tokens, r.model))
    others_model: Optional[AgentModelOthersViewModel] = None
    if len(model_rows) > 8:
        rest_models = model_rows[8:]
        rest_tokens = sum(m.tokens for m in rest_models)
        rest_cost = sum(m.cost for m in rest_models)
        others_model = AgentModelOthersViewModel(
            count=len(rest_models),
            tokens=rest_tokens,
            tokens_str=format_tokens(rest_tokens, lang),
            cost=rest_cost,
            cost_str=format_money(rest_cost),
        )
        model_rows = model_rows[:8]

    # Where the money went (this agent's cost by project: top 4 + others)
    raw_proj: List[Tuple[str, str, float]] = []
    for p in filtered.projects:
        if not isinstance(p, dict):
            continue
        p_ag = next((a for a in (p.get("by_agent") or []) if isinstance(a, dict) and a.get("agent") == agent), None)
        if p_ag is None:
            continue
        try:
            pc = float(p_ag.get("cost") or 0.0)
        except (TypeError, ValueError):
            pc = 0.0
        if pc > 0:
            raw_proj.append((str(p.get("id") or ""), str(p.get("name") or "Unnamed"), pc))
    raw_proj.sort(key=lambda item: (-item[2], item[0]))

    proj_shares: List[AgentProjectShareViewModel] = []
    others_share: Optional[AgentProjectOthersViewModel] = None
    total_proj_cost = sum(item[2] for item in raw_proj)
    if total_proj_cost > 0:
        for idx, (pid, pname, pc) in enumerate(raw_proj[:4]):
            sh = pc / total_proj_cost
            proj_shares.append(AgentProjectShareViewModel(
                project_id=pid,
                project_name=pname,
                cost=pc,
                cost_str=format_money(pc),
                share=sh,
                share_str=format_percent(sh),
                color=_project_segment_color(agent, idx),
            ))
        rest = raw_proj[4:]
        if rest:
            rest_cost = sum(item[2] for item in rest)
            if rest_cost > 0:
                sh = rest_cost / total_proj_cost
                others_share = AgentProjectOthersViewModel(
                    count=len(rest),
                    cost=rest_cost,
                    cost_str=format_money(rest_cost),
                    share=sh,
                    share_str=format_percent(sh),
                    color=DEFAULT_AGENT_COLOR,
                )

    account_shares = (
        compute_antigravity_account_shares(doc, time_range=time_range, now=now_dt, lang=lang)
        if agent == "antigravity"
        else []
    )

    return AgentDetailViewModel(
        agent=agent,
        label=label,
        color=agent_color(agent),
        plan_label=plan_label,
        price_str=price_str,
        multiplier_str=multiplier_str,
        cost_str=format_money(range_cost),
        tokens_str=format_tokens(range_tokens, lang),
        sessions_str=str(range_sessions),
        input_tokens=inp,
        output_tokens=out_tok,
        cache_read_tokens=cr,
        cache_write_tokens=cw,
        input_str=format_tokens(inp, lang),
        output_str=format_tokens(out_tok, lang),
        cache_read_str=format_tokens(cr, lang),
        cache_write_str=format_tokens(cw, lang),
        cache_hit_rate=hit_ratio,
        cache_hit_str=format_percent(hit_ratio),
        tps=tps,
        ttft_median=ttft_med,
        perf_samples=samples,
        speed_str=speed_detail_str,
        ttft_str=format_ttft(ttft_med),
        samples_str=samples_str,
        models=model_rows,
        project_shares=proj_shares,
        others_project_share=others_share,
        account_shares=account_shares,
        others_model=others_model,
    )
