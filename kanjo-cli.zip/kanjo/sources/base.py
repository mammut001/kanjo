"""Common session model and helpers shared by the log parsers."""

from __future__ import annotations

import contextlib
import json
import os
import posixpath
import re
import shutil
import sqlite3
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, Iterable, List, Optional

from .. import winsupport

AGENT_LABELS = {
    "claude": "Claude Code",
    "antigravity": "Antigravity CLI",
    "codex": "Codex CLI",
    "grok": "Grok CLI",
    "qwen": "Qwen Code",
    "commandcode": "Command Code",
    "minimax": "MiniMax",
    "opencode": "OpenCode",
    "copilot": "Copilot CLI",
    "pi": "Pi",
    "workbuddy": "WorkBuddy",
    "workbuddy_ai": "WorkBuddy Intl.",
    "qwenwork": "QwenWork",
    "grok_bot": "Grok Bot",
    "qoderwork": "QoderWork",
    "qodercli": "Qoder CLI",
    "qodercli_cn": "Qoder CN",
    "zcode": "ZCode",
    "kimicode": "Kimi Code",
    "musecode": "Muse Code",
    "codebuddy": "CodeBuddy",
    "qoder_ide": "Qoder IDE",
    "hermes": "Hermes",
    "openclaw": "OpenClaw",
    "devin": "Devin",
    "mimocode": "MiMo Code",
    "prime_agent": "Prime Agent",
    "omp": "OMP",
    "deepseek_harness": "DeepSeek Harness",
}


@dataclass
class Message:
    """One billed model response."""
    ts: float                      # epoch seconds (UTC)
    model: str
    input: int = 0                 # non-cached input
    output: int = 0                # includes thinking
    cache_read: int = 0
    cache_write: int = 0
    cache_write_1h: int = 0        # part of cache_write written with 1h TTL (Claude)
    thinking: int = 0              # subset of output
    cwd: Optional[str] = None
    branch: Optional[str] = None
    key: Optional[str] = None      # global de-duplication key


@dataclass
class Session:
    id: str
    agent: str
    file: str
    started: Optional[float] = None
    ended: Optional[float] = None
    # when this session itself began (first timestamp in file order, or the
    # agent's own creation time). Forks copy older messages, so ``started``
    # alone cannot tell the original from the copy.
    origin_ts: Optional[float] = None
    cwd: Optional[str] = None
    branch: Optional[str] = None
    messages: List[Message] = field(default_factory=list)
    # one entry per tool call: the unique absolute paths that call touched
    tool_paths: List[List[str]] = field(default_factory=list)
    subagent_of: Optional[str] = None
    title: Optional[str] = None
    # extra context paths (all message cwds, workspace roots) for the cwd /
    # scratchpad fallbacks; cwd counts weight the fallback choice
    cwd_counts: Dict[str, int] = field(default_factory=dict)
    # path -> git remote URL recorded by the agent itself
    remote_hints: Dict[str, str] = field(default_factory=dict)

    def note_time(self, ts: Optional[float]) -> None:
        if ts is None:
            return
        if self.started is None or ts < self.started:
            self.started = ts
        if self.ended is None or ts > self.ended:
            self.ended = ts

    def note_cwd(self, cwd: Optional[str], weight: int = 1) -> None:
        if cwd:
            self.cwd_counts[cwd] = self.cwd_counts.get(cwd, 0) + weight
            if self.cwd is None:
                self.cwd = cwd


class ParseError(Exception):
    """The file is not in a format this parser understands."""


def parse_iso(ts) -> Optional[float]:
    if not ts or not isinstance(ts, str):
        return None
    s = ts.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    # Python 3.9 fromisoformat accepts at most 6 fractional digits
    m = re.match(r"^(.*?\.\d{1,6})\d*(.*)$", s)
    if m:
        s = m.group(1) + m.group(2)
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.timestamp()


def iso_utc(ts: Optional[float]) -> Optional[str]:
    if ts is None:
        return None
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def local_day(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")


def local_timezone_name() -> str:
    """IANA name of the zone ``local_day`` uses: $TZ, else the /etc/localtime
    symlink target (macOS and most Linux), else /etc/timezone, else the UTC
    offset. Windows has no tz database path, so it always ends at the offset
    (``Etc/GMT+N`` or ``UTC``), which needs no ``tzdata`` package."""
    tz = os.environ.get("TZ", "").lstrip(":")
    if tz and "/" in tz and not tz.startswith("/"):
        return tz
    candidates = [tz] if tz.startswith("/") else []
    candidates.append("/etc/localtime")
    for link in candidates:
        try:
            target = os.path.realpath(link)
        except OSError:
            continue
        marker = "zoneinfo/"
        if marker in target:
            return target.split(marker, 1)[1]
    try:
        with open("/etc/timezone", "r", encoding="utf-8") as handle:
            name = handle.read().strip()
            if name:
                return name
    except OSError:
        pass
    return offset_timezone_name()


def offset_timezone_name() -> str:
    """The current UTC offset as a fixed zone name (``Etc/GMT+5`` or ``UTC``)."""
    offset = datetime.now().astimezone().utcoffset()
    if not offset:
        return "UTC"
    # no IANA name available: Etc/GMT zones have inverted signs
    hours = int(offset.total_seconds() // 3600)
    return "Etc/GMT%+d" % (-hours) if offset.total_seconds() % 3600 == 0 else "UTC"


def fixed_offset_tz(name: Optional[str]):
    """A fixed-offset tzinfo for an ``Etc/GMT±N`` name, without the tz database."""
    if name:
        m = re.match(r"^Etc/GMT([+-])(\d{1,2})$", name.strip())
        if m:
            hours = int(m.group(2))
            if m.group(1) == "+":
                hours = -hours  # Etc/GMT+5 is UTC-5
            return timezone(timedelta(hours=hours))
    local = datetime.now().astimezone().utcoffset() or timedelta(0)
    return timezone(local)


def local_zone(name: Optional[str] = None):
    """tzinfo for ``name`` (default: the local zone).

    Falls back to a fixed UTC offset when the IANA database is unavailable, which
    is the normal case on Windows without the ``tzdata`` package. Never raises, so
    no caller needs the tz database to exist.
    """
    zone_name = name or local_timezone_name()
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(zone_name)
    except Exception:
        return fixed_offset_tz(zone_name)


def _is_cjk(ch: str) -> bool:
    code = ord(ch)
    return (
        0x4E00 <= code <= 0x9FFF
        or 0x3400 <= code <= 0x4DBF
        or 0x20000 <= code <= 0x2A6DF
        or 0xF900 <= code <= 0xFAFF
        or 0x3040 <= code <= 0x309F
        or 0x30A0 <= code <= 0x30FF
        or 0xAC00 <= code <= 0xD7AF
    )


def _is_only_path(s: str) -> bool:
    t = s.strip().strip("\"'()[]{}").rstrip("…").rstrip(".")
    if not t:
        return True
    if re.match(r"^/(?:goal|plan|browser|compact|schedule|learn|boost|teamwork|grill-me)\b", t, re.I):
        return False
    if t.startswith(("http://", "https://", "git@", "ssh://")):
        return " " not in t
    if t.startswith(("~/", "./", "../")) or re.match(r"^[A-Za-z]:[/\\]", t):
        return " " not in t
    if t.startswith("/"):
        if " " not in t and "/" in t[1:]:
            return True
    return False


_PATH_RE = re.compile(r"(?:~|/|[A-Za-z]:[/\\])[^\s\"';|&<>(){}$,]*")
_ABBREVIATIONS = {"e.g", "i.e", "etc", "vs", "dr", "mr", "mrs", "ms"}
_TASK_SLASH_COMMANDS = {"goal", "plan", "task", "boost", "learn"}

_TAG_NAMES = {
    "environment_context", "recommended_plugins", "collaboration_mode",
    "permissions", "skills_instructions", "apps_instructions",
    "plugins_instructions", "app-context", "multi_agent_mode",
    "codex_internal_context", "local-command-caveat", "local-command-stdout",
    "task-notification", "command_output", "command-name", "command-message",
    "status", "output-file", "task-id", "tool-use-id", "summary",
    "transcript_delta", "source", "tags", "context", "cwd", "shell",
    "current_date", "timezone",
}


def _is_tag_line(line: str) -> bool:
    line = line.strip()
    if not line.startswith("<") or not line.endswith(">"):
        return False
    if re.fullmatch(r"(?:</?[A-Za-z0-9_-]+(?:\s+[^>]*)?>\s*)+", line):
        return True
    m = re.match(r"^<([A-Za-z0-9_-]+)(?:\s+[^>]*)?>.*</\1>$", line)
    if m and m.group(1).lower() in _TAG_NAMES:
        return True
    return False


def _is_git_diff_line(line: str) -> bool:
    s = line.strip()
    if re.match(r"^:\d{6}\s+\d{6}\b", s):
        return True
    if s.startswith(("diff --git ", "index ", "--- ", "+++ ", "@@ ")) or s.startswith("*** Begin Patch"):
        return True
    return False


def _is_json_or_mostly_punctuation(line: str) -> bool:
    s = line.strip()
    if (s.startswith("{") and s.endswith("}")) or (s.startswith("[") and s.endswith("]")):
        try:
            parsed = json.loads(s)
            if isinstance(parsed, (dict, list)):
                return True
        except Exception:
            pass
    chars = [c for c in s if not c.isspace()]
    if not chars:
        return True
    alnum = sum(1 for c in chars if c.isalnum() or _is_cjk(c))
    if alnum == 0 or (alnum / len(chars) < 0.3):
        return True
    return False


def _is_lead_in_colon_line(line: str) -> bool:
    s = line.strip()
    if s.endswith(":") or s.endswith("："):
        words = s.split()
        if len(words) < 6:
            return True
    return False


def _is_work_instruction_or_mostly_path(line: str) -> bool:
    s = line.strip()
    if re.match(r"^\s*#*\s*(?:work\s+only|only\s+modify|you\s+are\s+working)\b", s, re.I):
        return True
    if "/" in s or "~" in s or "\\" in s:
        remainder = _PATH_RE.sub("", s)
        words = re.findall(r"\w+", remainder)
        if len(words) <= 2:
            return True
    return False


def _is_slash_command_only(text: str) -> bool:
    s = text.strip()
    m = re.match(r"^/([a-zA-Z0-9_-]+)(?:\s+(.*))?$", s)
    if not m:
        return False
    cmd = m.group(1).lower()
    args = (m.group(2) or "").strip()
    if cmd in _TASK_SLASH_COMMANDS:
        return len(args) == 0
    return True


def _find_sentence_end(text: str) -> Optional[int]:
    cjk_matches = [m.end() for m in re.finditer(r"[。！？]", text)]
    eng_ends = []
    for m in re.finditer(r"([.!?])(?=[\s\"'«»“”\)]|$)", text):
        dot_idx = m.start(1)
        if dot_idx > 0 and text[dot_idx - 1] in ".!?":
            continue
        if dot_idx > 0 and text[dot_idx - 1].isdigit() and dot_idx + 1 < len(text) and text[dot_idx + 1].isdigit():
            continue
        prefix = text[:dot_idx]
        last_word = re.search(r"([A-Za-z]+)$", prefix)
        if last_word and last_word.group(1).lower() in _ABBREVIATIONS:
            continue
        end_idx = m.end(1)
        while end_idx < len(text) and text[end_idx] in "\"'«»“”)]}":
            end_idx += 1
        eng_ends.append(end_idx)

    candidates = cjk_matches + eng_ends
    if not candidates:
        return None
    return min(candidates)


def clean_title(text) -> Optional[str]:
    """Pure title cleaner used by all session parsers.

    Strips markdown heading markers and leading 'Task:' / 'TASK:' / '任务：',
    drops lines that are only metadata (Worktree:, Branch:, Base commit:,
    paths, code fences, <tags>), collapses whitespace, cuts at the first
    sentence end or ~80 chars on a word/character boundary (CJK-aware) with '…'.
    Never returns a title that is only a path.
    """
    if not isinstance(text, str):
        return None
    if "<source>transcript_tail_flush</source>" in text:
        return None
    if re.match(r"^#*\s*AGENTS\.md\b", text.strip(), re.I):
        return None

    # Skip whole-message JSON or slash-command-only
    trimmed = text.strip()
    if _is_slash_command_only(trimmed):
        return None
    if (trimmed.startswith("{") and trimmed.endswith("}")) or (trimmed.startswith("[") and trimmed.endswith("]")):
        try:
            parsed = json.loads(trimmed)
            if isinstance(parsed, (dict, list)):
                return None
        except Exception:
            pass

    m_in = re.search(r"<input>(.*?)</input>", text, re.DOTALL | re.I)
    if m_in and m_in.group(1).strip():
        text = m_in.group(1).strip()
        if _is_slash_command_only(text.strip()):
            return None

    lines = text.splitlines()
    candidate = None
    in_code = False
    in_tag = None
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith("```") or line.startswith("~~~"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if in_tag:
            if f"</{in_tag}>" in line:
                in_tag = None
            continue
        m_start = re.match(r"^<([A-Za-z0-9_-]+)(?:\s+[^>]*)?>", line)
        if m_start:
            tag = m_start.group(1).lower()
            if tag in _TAG_NAMES:
                if f"</{tag}>" not in line:
                    in_tag = tag
                continue
        if _is_tag_line(line):
            continue
        if _is_git_diff_line(line):
            continue
        if _is_json_or_mostly_punctuation(line):
            continue
        if _is_work_instruction_or_mostly_path(line):
            continue
        if _is_lead_in_colon_line(line):
            continue
        if _is_slash_command_only(line):
            continue
        if re.match(r"^#*\s*(?:Files (?:pasted|mentioned) by the user|已粘贴的文本)\b", line, re.I):
            continue
        if "This session is being continued from a previous conversation" in line:
            continue
        if re.match(r"^(?:Summary|Overview|Context)\s*:\s*$", line, re.I):
            continue
        if re.match(r"^(\d+\.|\*|-)?\s*(primary request|overview|context|intent|goals?)\b", line, re.I):
            continue
        if re.match(r"^#*\s*My request\s*:\s*$", line, re.I):
            continue
        if "AGENTS.md" in line:
            continue

        if re.match(r"^(?:worktree|branch|base commit|workspace)\s*:", line, re.I):
            remainder = re.sub(r"(?:worktree|branch|base commit|workspace)\s*:\s*\S+", "", line, flags=re.I).strip()
            if not remainder or _is_only_path(remainder):
                continue
            line = remainder

        line = re.split(r"(?:\s{2,}|\s+)(?:Worktree|Branch|Base commit):", line, flags=re.I)[0].strip()

        m_pasted = re.match(r"^#*\s*[\"\'“](.+?)[\"\'”]\s*:\s*(?:~|/|\.\w+).*$", line)
        if m_pasted:
            line = m_pasted.group(1)

        while True:
            new_line = re.sub(r"^\s*#{1,6}\s*", "", line)
            new_line = re.sub(r"^(?:task|任务)\s*[:：]\s*", "", new_line, flags=re.I)
            if new_line == line:
                break
            line = new_line

        # Unwrap slash commands with task (e.g. /goal ...)
        m_cmd = re.match(r"^/(?:goal|plan|task|boost|learn)\s+(.+)$", line, re.I)
        if m_cmd:
            line = m_cmd.group(1).strip()

        line = re.sub(r"^\s*(?:[-*]|\d+\.)\s*", "", line)
        line = re.sub(r"^\*\*[^*]+(?:\*\*:|\*\*)\s*", "", line)
        line = line.strip("\"'«»“” ")
        line = re.sub(r"<[^>]+>", "", line).strip()

        if (
            not line
            or _is_only_path(line)
            or _is_lead_in_colon_line(line)
            or _is_work_instruction_or_mostly_path(line)
            or _is_json_or_mostly_punctuation(line)
        ):
            continue

        candidate = line
        break

    if not candidate:
        return None

    text = " ".join(candidate.split())
    if (
        not text
        or _is_only_path(text)
        or _is_lead_in_colon_line(text)
        or _is_json_or_mostly_punctuation(text)
        or _is_work_instruction_or_mostly_path(text)
    ):
        return None

    first_end = _find_sentence_end(text)
    if first_end is not None and first_end <= 80:
        return text[:first_end].strip()

    if len(text) <= 80:
        return text

    limit = 79
    if _is_cjk(text[limit - 1]) or _is_cjk(text[limit]):
        cut_pos = limit
    else:
        pos = limit
        while pos > 40 and text[pos] != " ":
            pos -= 1
        cut_pos = pos if text[pos] == " " else limit

    cut = text[:cut_pos].rstrip(" \t\r\n,;:.-")
    cut = cut.rstrip("….").rstrip()
    return cut + "…"


short_title = clean_title


# ---- path extraction -------------------------------------------------------
# An absolute (or ~/) path in free text. It must start the text or follow a
# separator, so "https://host/x" and "a/b" do not match. Parsing stops at
# whitespace, quotes, semicolons and backticks (ATTRIBUTION.md section 9), and
# at shell operators.
_UNQUOTED_PATH = re.compile(r"""(?<![^\s"'`=(<>|&;,])((?:~|/)[^\s"'`;|&<>(){}$,]*)""")
_QUOTED_PATH = re.compile(r"""(["'])((?:~|/)[^"'\r\n`;]*?)\1""")
# Windows paths in free text: C:\a\b, c:/a/b, \\server\share. Only used on Windows
# (or when the text itself names a drive path), so POSIX extraction is unchanged.
_UNQUOTED_WIN_PATH = re.compile(
    r"""(?<![^\s"'`=(<>|&;,])((?:[A-Za-z]:[\\/]|\\\\|~/)[^\s"'`;|&<>(){}$,]*)""")
_QUOTED_WIN_PATH = re.compile(r"""(")([A-Za-z]:[\\/][^"\r\n`;]*)"|(')([A-Za-z]:[\\/][^'\r\n`;]*)'""")
_TRAILING = ".,:;)]}\\"
_VALID_SECOND_CHAR = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._~-")


def _expand_home(p: str, home: str) -> str:
    """``~`` -> ``home`` with the separator style of the home path."""
    if p == "~":
        return home
    rest = p[2:]
    if winsupport.is_windows_path(home):
        parts = [part for part in re.split(r"[\\/]+", rest) if part]
        return winsupport.join(home, *parts) if parts else home
    return home + p[1:]


def _finish(path: str, home: str) -> Optional[str]:
    if "\n" in path or "\r" in path:
        return None
    p = path.rstrip(_TRAILING)
    if "\n" in p or "\r" in p:
        return None
    if p.startswith("~"):
        if not (p == "~" or p.startswith("~/") or p.startswith("~\\")):
            return None
        p = _expand_home(p, home)
    is_win = bool(re.match(r"^(?:[A-Za-z]:[\\/]|\\\\)", p))
    if not (p.startswith("/") or is_win):
        return None
    if p.startswith("/") and (len(p) < 2 or p.startswith("//") or p[1] not in _VALID_SECOND_CHAR):
        return None
    return winsupport.normpath(p)


def _wants_windows_paths(text: str) -> bool:
    """Extract drive/UNC paths too: always on Windows, and for text that names one.

    macOS logs can still contain a Windows command (a session about a Windows
    build), so a ``C:\\...`` or ``\\\\server\\share`` in the text is recognised on
    any host.
    """
    return winsupport.is_windows() or bool(
        re.search(r"""(?:^|[\s"'`=(])(?:[A-Za-z]:[\\/]|\\\\)""", text))


def extract_paths(text: str, home: Optional[str] = None) -> List[str]:
    """Absolute paths mentioned in a shell command (or similar free text).
    Quoted paths may contain spaces; an unquoted path inside a quoted span is
    not counted again."""
    if not text or not isinstance(text, str):
        return []
    windows = _wants_windows_paths(text)
    if "/" not in text and "~" not in text and "\\" not in text and not windows:
        return []
    home = home or winsupport.expanduser("~")
    found: List[str] = []
    spans = []
    for m in _QUOTED_PATH.finditer(text):
        p = _finish(m.group(2), home)
        spans.append((m.start(), m.end()))
        if p:
            found.append(p)
    if windows:
        for m in _QUOTED_WIN_PATH.finditer(text):
            if spans and any(a <= m.start() < b for a, b in spans):
                continue
            value = m.group(2) if m.group(2) is not None else m.group(4)
            p = _finish(value, home)
            spans.append((m.start(), m.end()))
            if p and p not in found:
                found.append(p)
    for m in _UNQUOTED_PATH.finditer(text):
        if spans and any(a <= m.start() < b for a, b in spans):
            continue
        p = _finish(m.group(1), home)
        if p:
            found.append(p)
    if windows:
        for m in _UNQUOTED_WIN_PATH.finditer(text):
            if spans and any(a <= m.start() < b for a, b in spans):
                continue
            p = _finish(m.group(1), home)
            if p and p not in found:
                found.append(p)
    return found


def absolutize(path, cwd: Optional[str], home: Optional[str] = None) -> Optional[str]:
    """A path value from a tool argument: absolute, ~/, file:// or relative to cwd."""
    if not isinstance(path, str):
        return None
    p = path.strip()
    if not p or "\n" in p or len(p) > 4096:
        return None
    if p.startswith("file://"):
        from urllib.parse import unquote
        p = unquote(p[len("file://"):])
        if re.match(r"^/[A-Za-z]:", p):
            p = p[1:]
    if p.startswith("~/") or p == "~" or p.startswith("~\\"):
        p = _expand_home(p, home or winsupport.expanduser("~"))
    is_abs = p.startswith("/") or winsupport.is_windows_path(p)
    if not is_abs:
        if not cwd or re.match(r"^[a-z][a-z0-9+.\-]*:", p, re.I):
            return None
        if winsupport.is_windows_path(cwd):
            # Node tools write relative paths with either separator.
            return winsupport.normpath(winsupport.join(cwd, *[x for x in re.split(r"[\\/]+", p) if x]))
        p = posixpath.join(cwd, *[x for x in p.split("/") if x])
    return winsupport.normpath(p)


def unique(items: Iterable[str]) -> List[str]:
    seen = set()
    out = []
    for item in items:
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return out


def split_path_list(value: str) -> List[str]:
    """A ``PATH``-style list. ``;`` separates Windows paths, ``:`` POSIX paths.

    Windows uses ``;`` and drive letters contain a ``:``, so a list that looks like
    Windows paths is always split on ``;`` first — also when this runs on macOS
    (tests set ``C:\\a;C:\\b``). POSIX values keep using ``os.pathsep``.
    """
    if ";" in value and re.search(r"(?:^|;)\s*[A-Za-z]:[\\/]", value):
        return [p for p in value.split(";") if p]
    return [p for p in value.split(os.pathsep) if p]


def env_dirs(var: str, defaults: List[str]) -> List[str]:
    value = os.environ.get(var)
    if value:
        return [winsupport.expanduser(p) for p in split_path_list(value)]
    if os.environ.get("KANJO_DATA_DIR"):
        return []
    return [winsupport.expanduser(p) for p in defaults]


def platform_dirs(defaults: List[str], windows_defaults: Optional[List[str]] = None) -> List[str]:
    """Every default root for this platform, expanded.

    ``defaults`` are the macOS/Linux locations; ``windows_defaults`` replace them
    on Windows. Without an explicit Windows list, the same names are used, which is
    correct for dot-dirs: ``~/.claude`` expands to ``%USERPROFILE%\\.claude`` there.
    """

    chosen = defaults
    if windows_defaults is not None and winsupport.is_windows():
        chosen = windows_defaults
    return [winsupport.expanduser(p) for p in chosen]


def paths_from_args(args, cwd: Optional[str], path_keys, cmd_keys, home: Optional[str] = None) -> List[str]:
    """Paths in a tool call's argument dict. ``path_keys`` hold a path (or a
    list of paths); ``cmd_keys`` hold shell text that is scanned for absolute
    paths. Key matching is case-insensitive."""
    out: List[str] = []
    if not isinstance(args, dict):
        return out
    for key, value in args.items():
        k = str(key).lower()
        if k in path_keys:
            values = value if isinstance(value, list) else [value]
            for v in values:
                p = absolutize(v, cwd, home)
                if p:
                    out.append(p)
        elif k in cmd_keys:
            if isinstance(value, list):
                value = " ".join(str(v) for v in value)
            out.extend(extract_paths(value, home))
    return out


def git_branch(cwd: Optional[str]) -> Optional[str]:
    """Recover branch name from .git/HEAD in cwd (or linked worktree) without invoking git."""
    if not cwd or not os.path.isdir(cwd):
        return None
    win = winsupport.is_windows_path(cwd)
    dotgit = os.path.join(cwd, ".git")
    head_file = None
    if os.path.isdir(dotgit):
        head_file = os.path.join(dotgit, "HEAD")
    elif os.path.isfile(dotgit):
        try:
            with open(dotgit, "r", encoding="utf-8") as f:
                line = f.read().strip()
                if line.startswith("gitdir:"):
                    gdir = line.split(":", 1)[1].strip()
                    if win:
                        # git writes "C:/..." (forward slashes) even on Windows.
                        if not (os.path.isabs(gdir) or winsupport.is_windows_path(gdir)):
                            gdir = winsupport.normpath(winsupport.join(cwd, gdir))
                        head_file = winsupport.join(gdir, "HEAD")
                    else:
                        if not os.path.isabs(gdir):
                            gdir = os.path.normpath(os.path.join(cwd, gdir))
                        head_file = os.path.join(gdir, "HEAD")
        except OSError:
            pass
    if head_file and os.path.isfile(head_file):
        try:
            with open(head_file, "r", encoding="utf-8") as hf:
                c = hf.read().strip()
                if c.startswith("ref: refs/heads/"):
                    return c[len("ref: refs/heads/"):].strip()
        except OSError:
            pass
    return None


def sqlite_uri_path(path: str) -> str:
    """The path part of a SQLite ``file:`` URI.

    Windows paths need the URI form ``file:///C:/dir/db`` (``file:C:\\dir\\db`` is
    not a valid URI there; SQLite treats the ``C:`` as a scheme). POSIX paths keep
    the ``/abs/path`` spelling they always had.
    """
    if winsupport.is_windows_path(path):
        from urllib.parse import quote
        return "/" + quote(path.replace("\\", "/"), safe="/:")
    if path.startswith("/"):
        # A POSIX path stays POSIX even on a Windows host (logs from another machine).
        return posixpath.normpath(path)
    return os.path.abspath(path)


@contextlib.contextmanager
def open_sqlite_ro(path: str):
    """Open SQLite db in read-only mode.
    Tries direct connection with mode=ro first, avoiding copying. Falls back to
    copying db + -wal + -shm to temp only on 'unable to open'/locked errors.
    Never uses immutable=1 when a -wal exists.
    """
    if not os.path.isfile(path):
        raise ParseError("database file not found: %s" % path)

    abs_path = sqlite_uri_path(path)
    wal_exists = os.path.isfile(path + "-wal")
    direct_conn = None
    try:
        c = sqlite3.connect(f"file:{abs_path}?mode=ro", uri=True, timeout=1)
        try:
            c.execute("SELECT 1 FROM sqlite_master LIMIT 1")
        except sqlite3.Error:
            # A connection that fails its probe still holds the file open; on
            # Windows that blocks the caller's cleanup (WinError 32).
            c.close()
            raise
        direct_conn = c
    except sqlite3.Error:
        if not wal_exists:
            try:
                c = sqlite3.connect(f"file:{abs_path}?mode=ro&immutable=1", uri=True, timeout=1)
                try:
                    c.execute("SELECT 1 FROM sqlite_master LIMIT 1")
                except sqlite3.Error:
                    c.close()
                    raise
                direct_conn = c
            except sqlite3.Error:
                pass

    if direct_conn is not None:
        try:
            yield direct_conn
            return
        finally:
            direct_conn.close()

    tmp_dir = tempfile.mkdtemp(prefix="kanjo-db-")
    try:
        tmp_db = os.path.join(tmp_dir, os.path.basename(path))
        shutil.copy2(path, tmp_db)
        if wal_exists:
            try:
                shutil.copy2(path + "-wal", tmp_db + "-wal")
            except OSError:
                pass
        shm_path = path + "-shm"
        if os.path.isfile(shm_path):
            try:
                shutil.copy2(shm_path, tmp_db + "-shm")
            except OSError:
                pass
        conn = sqlite3.connect(tmp_db)
        try:
            yield conn
        finally:
            conn.close()
    except (sqlite3.Error, OSError) as exc:
        raise ParseError("cannot open database %s: %s" % (path, exc))
    finally:
        if os.path.exists(tmp_dir):
            shutil.rmtree(tmp_dir, ignore_errors=True)

